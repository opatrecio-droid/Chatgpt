"""Read/download public author-linked asset files. No credential extraction."""
import codecs,json,re,subprocess
from pathlib import Path

def fetch(url, destination=None):
    cmd=['curl','-fLsS','--retry','1','--connect-timeout','15','--max-time','90',url]
    if destination:
        destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(cmd+['-o',str(destination)],check=True);return destination
    return subprocess.check_output(cmd)

def list_folder(folder_id):
    html=fetch('https://drive.google.com/drive/folders/'+folder_id).decode()
    match=re.search(r"window\['_DRIVE_ivd'\]\s*=\s*'((?:\\.|[^'])*)'",html)
    if not match:raise RuntimeError('Public folder listing not found')
    encoded=match.group(1)
    decoded=codecs.decode(encoded,'unicode_escape').replace('\\/','/')
    listing=json.loads(decoded)
    return [{'id':row[0],'name':row[2],'type':row[3]} for row in listing[0] or []]

def download(file_id,destination):
    destination=fetch('https://drive.google.com/uc?export=download&id='+file_id,destination)
    head=destination.read_bytes()[:300]
    if b'<html' in head.lower() or b'<!doctype' in head.lower():
        raise RuntimeError('Download returned HTML instead of an asset: '+str(destination))
    return destination

if __name__=='__main__':
    import sys
    print(json.dumps(list_folder(sys.argv[1]),indent=2))
