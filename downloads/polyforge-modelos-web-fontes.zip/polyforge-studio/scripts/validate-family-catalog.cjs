const { chromium }=require('playwright');
const fs=require('fs');
const assert=(ok,msg)=>{if(!ok)throw Error(msg)};
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1600,height:1000},acceptDownloads:true});const errors=[];const external=[];
 page.on('pageerror',e=>errors.push(e.message));await page.route('https://**/*',r=>{external.push(r.request().url());return r.abort()});
 try{
 await page.goto(process.env.BASE_URL||'http://127.0.0.1:8000');await page.waitForFunction(()=>typeof currentModelGroup!=='undefined'&&currentModelGroup);
 const audit=await page.evaluate(()=>{
  const all=getFilteredAssets();const original=all.filter(a=>!a.pack).length;const families=all.filter(a=>a.pack).length;
  showExpansionAssets();const expansion=getFilteredAssets();const keys=expansion.map(getAssetFamilyKey);const cards=document.querySelectorAll('#asset-list .asset-card').length;
  setAssetPage(2);const secondPage=document.querySelectorAll('#asset-list .asset-card').length;
  setCategory('characters');const characterFamilies=getFilteredAssets().length;
  const family=ASSET_CATALOG.find(a=>a.pack==='characters'&&a.form==='mage'&&a.variant===0);selectAsset(family.id);
  const variants=document.querySelectorAll('#asset-variant-select option').length;
  const id=ASSET_CATALOG.find(a=>a.pack==='characters'&&a.form==='mage'&&a.variant===7).id;chooseFamilyVariant(id);
  const changed=state.selectedAssetId===id&&document.querySelector('#asset-variant-select').value===id;
  const sameCount=getFilteredAssets().length===characterFamilies;
  const oneCard=document.querySelectorAll('#asset-list .asset-card.active').length===1;
  const explicit=document.getElementById('family-variants').textContent.includes('Não conta como outro modelo único.');
  document.getElementById('library-biome').value='crystal';setCategory('nature');filterAssets();const natureCrystal=getFilteredAssets().length;
  const familiesReport=EXPANSION_PACKS.flatMap(pack=>{
    const forms=[...new Set(pack.assets.map(a=>a.form))];return forms.map(form=>({pack:pack.assets[0].pack,form,configurations:pack.assets.filter(a=>a.form===form).length,visuallyDistinctModelsVerified:false}));
  });
  return {scope:'Catalog grouping and variant navigation, not a claim of visual uniqueness',originalEntries:original,proceduralFamilies:families,browseEntries:all.length,expansionFamilyCount:expansion.length,uniqueFamilyKeys:new Set(keys).size,cards,secondPage,characterFamilies,variants,changed,sameCount,oneCard,explicit,natureCrystal,internalConfigurationCount:ASSET_CATALOG.length,familiesReport};
 });
 assert(audit.originalEntries===126&&audit.proceduralFamilies===100&&audit.browseEntries===226,'Incorrect grouping totals');
 assert(audit.expansionFamilyCount===100&&audit.uniqueFamilyKeys===100,'Duplicate families in catalog');
 assert(audit.cards===72&&audit.secondPage===28,'Wrong pagination');
 assert(audit.characterFamilies===25&&audit.natureCrystal===25,'Wrong category/biome family count');
 assert(audit.variants===10&&audit.changed&&audit.sameCount&&audit.oneCard&&audit.explicit,'Variant selection not separated from family count');
 await page.evaluate(()=>{document.getElementById('library-biome').value='expansion';setCategory('characters');selectAsset('charx_02_08');setCameraView('perspective')});
 await page.screenshot({path:'/workspace/artifacts/polyforge-catalogo-corrigido.png'});
 const download=page.waitForEvent('download');await page.evaluate(()=>exportToOBJ());const obj=await download;await obj.saveAs('/workspace/artifacts/'+obj.suggestedFilename());
 await page.setViewportSize({width:390,height:844});await page.reload();await page.waitForFunction(()=>typeof currentModelGroup!=='undefined'&&currentModelGroup);
 const mobile=await page.evaluate(()=>({width:document.body.scrollWidth,canvas:document.getElementById('viewport-container').clientWidth}));assert(mobile.width===390&&mobile.canvas===390,'Mobile layout overflow');
 assert(!errors.length&&!external.length,'Browser or network failures');
 const report={...audit,mobile,browserErrors:errors,externalRequests:external,requested1000DistinctModelsDelivered:false};
 fs.writeFileSync('/workspace/artifacts/auditoria-catalogo.json',JSON.stringify(report,null,2));
 console.log(JSON.stringify({...report,familiesReport:report.familiesReport.length}));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
