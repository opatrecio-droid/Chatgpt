"""Embed the editable pack sources into the portable application HTML."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
path=root/'index.html'
html=path.read_text()
paths=[root/'src/packs'/f'{name}.js' for name in ('nature','animals','objects','characters')]+[root/'src/expansion.js']
source='\n\n'.join(p.read_text() for p in paths)
source+='\nconst EXPANSION_BIOMES=expansionBiomes();\nconst EXPANSION_PACKS=[createNaturePack(EXPANSION_BIOMES),createAnimalsPack(EXPANSION_BIOMES),createObjectsPack(EXPANSION_BIOMES),createCharactersPack(EXPANSION_BIOMES)];\nconst EXPANSION_ASSET_INDEX=new Map(EXPANSION_PACKS.flatMap(pack=>pack.assets.map(asset=>[asset.id,{asset,pack}])));\n'
start='// POLYFORGE_EXPANSION_START\n'
end='// POLYFORGE_EXPANSION_END\n'
if start in html:
    a=html.index(start)+len(start);b=html.index(end,a)
    html=html[:a]+source+'\n'+html[b:]
else:
    html=html.replace('        const ASSET_CATALOG = [', start+source+'\n'+end+'        const ASSET_CATALOG = [',1)
path.write_text(html)
print('Embedded four expansion packs and shared builder into',path)
