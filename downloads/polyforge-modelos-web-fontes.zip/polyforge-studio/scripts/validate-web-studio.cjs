const{chromium}=require('playwright');const fs=require('fs'),path=require('path'),crypto=require('crypto');
const assert=(value,message)=>{if(!value)throw Error(message)};
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1600,height:1000},acceptDownloads:true});page.setDefaultTimeout(120000);
 const errors=[],externals=[];page.on('pageerror',e=>errors.push(e.message));await page.route('https://**/*',route=>{externals.push(route.request().url());return route.abort()});
 const out='/workspace/artifacts';fs.mkdirSync(out,{recursive:true});fs.mkdirSync('/workspace/Chatgpt/assets/thumbnails',{recursive:true});
 try{
  await page.goto(process.env.BASE_URL||'http://127.0.0.1:8000',{timeout:120000});await page.waitForFunction(()=>typeof webReady!=='undefined'&&webReady,{timeout:120000});
  const models=await page.evaluate(()=>ASSET_CATALOG.map(a=>({id:a.id,name:a.name,category:a.category,sha256:a.sha256,author:a.author,license:a.license})));
  assert(models.length===35,'Unexpected visible GLB count');assert(models.every(a=>a.license==='CC0-1.0'&&a.sha256),'Missing license or hash');
  const results=[];
  for(const asset of models){
   const result=await page.evaluate(async id=>{
    selectAsset(id);clearLoadout();const template=NATIVE_TEMPLATES.get(id),actor=NATIVE_ACTORS.get(currentModelGroup);
    const sourcePositions=new Set();template.scene.traverse(n=>{if(n.isMesh)sourcePositions.add(n.geometry)});
    let meshes=0,skins=0,preserved=true,finite=true,untextured=false;
    currentModelGroup.traverse(n=>{if(n.isMesh){meshes++;if(n.isSkinnedMesh)skins++;if(!sourcePositions.has(n.geometry))preserved=false;const p=n.geometry.attributes.position;for(const v of p.array)if(!Number.isFinite(v))finite=false;const mats=Array.isArray(n.material)?n.material:[n.material];if(mats.some(m=>!m.color&&!m.map))untextured=true;}});
    const bounds=new THREE.Box3().setFromObject(currentModelGroup),size=bounds.getSize(new THREE.Vector3());
    const animationStates={};
    for(const state of ['idle','walk','jump','action']){
      const clip=actor.find(state);if(!clip){animationStates[state]='unavailable';continue;}
      actor.play(state);actor.update(.35);currentModelGroup.updateMatrixWorld(true);renderer.render(scene,camera);animationStates[state]=clip.name;
    }
    actor.play('idle');actor.update(.15);currentModelGroup.updateMatrixWorld(true);
    renderer.setSize(400,400,false);camera.aspect=1;camera.updateProjectionMatrix();setCameraView('perspective');renderer.render(scene,camera);
    const thumbnail=renderer.domElement.toDataURL('image/jpeg',.84).split(',')[1];
    return {id,meshes,skins,preserved,finite,untextured,bounds:size.toArray(),clips:actor.clips.map(c=>canonicalClipName(c.name)),animationStates,gl:renderer.getContext().getError(),thumbnail};
   },asset.id);
   assert(result.preserved&&result.finite&&result.meshes&&result.bounds.every(n=>Number.isFinite(n)&&n>0),'Invalid or replaced geometry '+asset.id);
   assert(result.gl===0,'WebGL error '+asset.id);
   fs.writeFileSync('/workspace/Chatgpt/assets/thumbnails/'+asset.id+'.jpg',Buffer.from(result.thumbnail,'base64'));delete result.thumbnail;results.push(result);
   if(results.length%10===0)console.log('Verified authored GLBs:',results.length);
  }
  await page.evaluate(()=>{onWindowResize();selectAsset('web_characters_adventurer');setCategory('all');document.getElementById('library-biome').value='all';filterAssets();});
  const ui=await page.evaluate(()=>{const initial=getFilteredAssets().length;document.getElementById('library-biome').value='Kenney';filterAssets();const kenney=getFilteredAssets().length;document.getElementById('library-biome').value='all';setCategory('pets');const animals=getFilteredAssets().length;document.getElementById('search-input').value='lobo';filterAssets();const search=getFilteredAssets().map(a=>a.id);document.getElementById('search-input').value='';setCategory('all');selectAsset('web_nature_mushroom');const staticWalkDisabled=document.querySelector('[data-anim="walk"]').disabled;selectAsset('web_characters_adventurer');const originalCount=nativeMaterials().length;const source=nativeMaterials()[0].color.getHexString();document.getElementById('color-primary').value='#ff0000';updateModelAppearance();const tinted=nativeMaterials()[0].color.getHexString()!==source;resetCurrentModelSettings();const restored=nativeMaterials()[0].color.getHexString()===source;setEquippedPet('web_animals_fox');const companion=!!companionPetGroup;switchMode('sandbox');const x=currentModelGroup.position.x;keysPressed.KeyD=true;updateSandboxGameplay(.2,2);keysPressed.KeyD=false;const moved=currentModelGroup.position.x>x;switchMode('studio');clearLoadout();randomizeLoadoutCombo();const combo=!!currentModelGroup&&!!companionPetGroup;clearLoadout();selectAsset('web_characters_adventurer');generateWorldBiome('forest');const sceneCount=customWorldProps.length,onlyDownloaded=customWorldProps.every(m=>m.userData.imported);clearCustomSceneProps();return{initial,kenney,animals,search,staticWalkDisabled,originalCount,tinted,restored,companion,moved,combo,sceneCount,onlyDownloaded};});
  assert(ui.initial===35&&ui.kenney===10&&ui.animals===10&&ui.search.length===1,'Catalog filters failed');assert(ui.staticWalkDisabled&&ui.tinted&&ui.restored&&ui.companion&&ui.moved&&ui.combo&&ui.onlyDownloaded,'Viewer functional check failed');
  for(const fn of ['downloadNativeGLB','exportToOBJ','saveStudioImage','downloadStarterGameHTML']){
    const pending=page.waitForEvent('download');await page.evaluate(name=>window[name](),fn);const download=await pending,target=path.join(out,download.suggestedFilename());await download.saveAs(target);const bytes=fs.readFileSync(target);assert(bytes.length>100,'Empty export '+fn);
    if(fn==='downloadNativeGLB')assert(crypto.createHash('sha256').update(bytes).digest('hex')===models.find(a=>a.id==='web_characters_adventurer').sha256,'GLB download differs from original authored file');
    if(fn==='exportToOBJ')assert(/^v /m.test(bytes.toString())&&/^f /m.test(bytes.toString()),'Missing OBJ geometry');
    if(fn==='downloadStarterGameHTML'){
      const game=await browser.newPage({viewport:{width:1280,height:800}});game.on('pageerror',e=>errors.push('game: '+e.message));await game.route('https://**/*',r=>{externals.push(r.request().url());return r.abort()});await game.setContent(bytes.toString(),{waitUntil:'domcontentloaded',timeout:120000});await game.waitForFunction(()=>typeof player!=='undefined'&&player,{timeout:120000});const before=await game.evaluate(()=>player.position.x);await game.keyboard.down('KeyD');await game.waitForTimeout(200);await game.keyboard.up('KeyD');assert(await game.evaluate(x=>player.position.x>x,before),'Exported game movement failed');await game.keyboard.down('Space');await game.waitForTimeout(100);assert(await game.evaluate(()=>player.position.y>0),'Exported game jump failed');await game.keyboard.up('Space');await game.close();
    }
  }
  await page.setViewportSize({width:390,height:844});await page.reload({timeout:120000});await page.waitForFunction(()=>typeof webReady!=='undefined'&&webReady,{timeout:120000});const mobile=await page.evaluate(()=>({body:document.body.scrollWidth,canvas:document.getElementById('viewport-container').clientWidth}));assert(mobile.body===390&&mobile.canvas===390,'Mobile layout overflow');
  await page.screenshot({path:out+'/polyforge-web-mobile.png'});assert(!errors.length&&!externals.length,'Browser errors or external requests');
  const report={visibleAuthoredModels:models.length,models:results,ui,mobile,errors,externals,originalGLBHashVerified:true,exportedGameMovedAndJumped:true};fs.writeFileSync(out+'/validacao-modelos-web.json',JSON.stringify(report,null,2));console.log(JSON.stringify({...report,models:results.length}));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
