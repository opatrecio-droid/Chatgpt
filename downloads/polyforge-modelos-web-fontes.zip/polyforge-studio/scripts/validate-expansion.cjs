const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BASE_URL = process.env.BASE_URL || 'http://127.0.0.1:8000';
const OUTPUT_DIR = '/workspace/artifacts';
const EXPECTED = {
  total: 1126,
  expansion: 1000,
  packs: ['nature', 'animals', 'objects', 'characters'],
  biomes: ['forest', 'desert', 'tundra', 'swamp', 'savanna', 'ocean', 'volcanic', 'crystal', 'jungle', 'sky'],
  prefix: { nature: 'natx_', animals: 'petx_', objects: 'objx_', characters: 'charx_' }
};

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

(async () => {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const browser = await chromium.launch({
    executablePath: '/usr/bin/chromium',
    args: ['--no-sandbox', '--enable-unsafe-swiftshader']
  });
  const page = await browser.newPage({ viewport: { width: 1600, height: 1000 }, acceptDownloads: true });
  page.setDefaultTimeout(180000);
  const pageErrors = [];
  const remoteRequests = [];
  page.on('pageerror', error => pageErrors.push(error.message));
  await page.route('**/*', route => {
    const url = route.request().url();
    if (/^https?:\/\//.test(url) && !url.startsWith(BASE_URL)) {
      remoteRequests.push(url);
      return route.abort();
    }
    return route.continue();
  });

  try {
    await page.goto(BASE_URL, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => typeof ASSET_CATALOG !== 'undefined' && typeof buildProceduralModel === 'function' && typeof disposeModel === 'function', { timeout: 30000 });
    await page.waitForFunction(() => typeof renderer !== 'undefined' && renderer && currentModelGroup, { timeout: 30000 });

    const catalogResult = await page.evaluate(() => {
      const catalog = ASSET_CATALOG;
      const failures = [];
      const ids = new Set();
      const names = new Set();
      const expansion = catalog.filter(asset => ['nature', 'animals', 'objects', 'characters'].includes(asset.pack));
      const packCounts = Object.fromEntries(['nature', 'animals', 'objects', 'characters'].map(pack => [pack, 0]));
      const biomeForms = {};
      const formVariants = {};

      for (const asset of catalog) {
        if (ids.has(asset.id)) failures.push(`${asset.id}: duplicate id`);
        ids.add(asset.id);
        if (names.has(asset.name)) failures.push(`${asset.name}: duplicate name`);
        names.add(asset.name);
        if (!asset.pack) continue;
        packCounts[asset.pack] = (packCounts[asset.pack] || 0) + 1;
        if (typeof asset.id !== 'string' || !asset.id.startsWith(({ nature: 'natx_', animals: 'petx_', objects: 'objx_', characters: 'charx_' })[asset.pack])) failures.push(`${asset.id}: wrong pack id prefix`);
        if (!asset.biome || !asset.form || !Number.isInteger(asset.variant) || !Number.isInteger(asset.seed) || asset.seed <= 0) failures.push(`${asset.id}: missing expansion descriptor fields`);
        const key = `${asset.pack}/${asset.biome}`;
        biomeForms[key] ||= new Set();
        biomeForms[key].add(asset.form);
        formVariants[`${asset.pack}/${asset.form}`] ||= {};
        formVariants[`${asset.pack}/${asset.form}`][asset.variant] = asset;
      }

      return {
        total: catalog.length,
        expansion: expansion.length,
        packCounts,
        biomeForms: Object.fromEntries(Object.entries(biomeForms).map(([key, forms]) => [key, forms.size])),
        formVariants: Object.fromEntries(Object.entries(formVariants).map(([key, variants]) => [key, Object.keys(variants).length])),
        failures
      };
    });
    assert(catalogResult.total === EXPECTED.total, `Expected ${EXPECTED.total} catalog entries, got ${catalogResult.total}`);
    assert(catalogResult.expansion === EXPECTED.expansion, `Expected ${EXPECTED.expansion} expansion assets, got ${catalogResult.expansion}`);
    assert(catalogResult.failures.length === 0, `Catalog issues: ${catalogResult.failures.slice(0, 12).join('; ')}`);
    for (const pack of EXPECTED.packs) assert(catalogResult.packCounts[pack] === 250, `${pack}: expected 250 assets, got ${catalogResult.packCounts[pack]}`);
    for (const pack of EXPECTED.packs) for (const biome of EXPECTED.biomes) {
      assert(catalogResult.biomeForms[`${pack}/${biome}`] === 25, `${pack}/${biome}: expected 25 distinct forms, got ${catalogResult.biomeForms[`${pack}/${biome}`]}`);
    }

    const geometryResult = await page.evaluate(async () => {
      const failures = [];
      let meshes = 0;
      let maxMeshes = 0;
      let maxVertexCount = 0;
      const signatureByForm = new Map();
      const signatureByBiome = new Map();
      const sampleByPack = new Map();
      const numeric = value => Number.isFinite(value);
      const signature = group => {
        group.updateMatrixWorld(true);
        const parts = [];
        group.traverse(node => {
          if (!node.isMesh) return;
          const position = node.geometry && node.geometry.attributes && node.geometry.attributes.position;
          if (!position) throw new Error(`${node.name || 'mesh'} has no position attribute`);
          let vertexHash = 2166136261;
          for (const value of position.array) {
            if (!numeric(value)) throw new Error('nonfinite vertex position');
            vertexHash = Math.imul(vertexHash ^ Math.round(value * 1e5), 16777619);
          }
          maxVertexCount = Math.max(maxVertexCount, position.count);
          const m = node.matrixWorld.elements.map(n => Math.round(n * 1e5) / 1e5);
          parts.push(`${position.count}:${vertexHash >>> 0}:${m.join(',')}`);
        });
        return parts.sort().join('|');
      };

      for (let index = 0; index < ASSET_CATALOG.length; index++) {
        const asset = ASSET_CATALOG[index];
        let model = null;
        try {
          model = buildProceduralModel(asset.id, {
            primaryColor: asset.defaultColors.primary,
            secondaryColor: asset.defaultColors.secondary,
            accentColor: asset.defaultColors.accent,
            roughness: asset.roughness,
            metalness: asset.metalness,
            emissive: asset.emissive
          });
          if (!model) throw new Error('builder returned no model');
          model.updateMatrixWorld(true);
          const box = new THREE.Box3().setFromObject(model);
          const size = box.getSize(new THREE.Vector3());
          if (box.isEmpty() || ![box.min.x, box.min.y, box.min.z, box.max.x, box.max.y, box.max.z].every(numeric)) throw new Error('empty or nonfinite world bounds');
          if (![size.x, size.y, size.z].every(n => numeric(n) && n > 0)) throw new Error(`nonpositive dimensions ${size.toArray()}`);
          if (Math.abs(box.min.y) > 0.002) throw new Error(`model is not grounded (minY=${box.min.y})`);
          let count = 0;
          model.traverse(node => { if (node.isMesh) count++; });
          if (count === 0) throw new Error('no meshes');
          if (count > 90) throw new Error(`${count} meshes exceeds 90`);
          meshes += count;
          maxMeshes = Math.max(maxMeshes, count);
          const geomSig = signature(model);
          if (asset.pack) {
            const formKey = `${asset.pack}/${asset.form}`;
            signatureByForm.set(`${formKey}/${asset.variant}`, geomSig);
            const biomeKey = `${asset.pack}/${asset.biome}`;
            signatureByBiome.set(`${biomeKey}/${asset.form}`, geomSig);
            if (!sampleByPack.has(asset.pack)) sampleByPack.set(asset.pack, asset);
          }
        } catch (error) {
          failures.push({ id: asset.id, error: error.message });
        } finally {
          if (model) disposeModel(model);
        }
        if (index % 24 === 0) await new Promise(resolve => setTimeout(resolve, 0));
      }

      const forms = new Set(ASSET_CATALOG.filter(asset => asset.pack).map(asset => `${asset.pack}/${asset.form}`));
      const variantsDiffer = [];
      for (const key of forms) {
        const geometries = Array.from({ length: 10 }, (_, variant) => signatureByForm.get(`${key}/${variant}`));
        if (geometries.some(value => !value) || new Set(geometries).size !== 10) variantsDiffer.push(key);
      }

      const biomeGroups = new Set(ASSET_CATALOG.filter(asset => asset.pack).map(asset => `${asset.pack}/${asset.biome}`));
      const crossFormCollisions = [];
      for (const key of biomeGroups) {
        const signatures = ASSET_CATALOG.filter(asset => `${asset.pack}/${asset.biome}` === key).map(asset => signatureByBiome.get(`${key}/${asset.form}`));
        if (signatures.length !== 25 || signatures.some(value => !value) || new Set(signatures).size !== 25) crossFormCollisions.push({ biome: key, assetCount: signatures.length, uniqueShapes: new Set(signatures.filter(Boolean)).size });
      }

      const deterministic = [];
      for (const [pack, asset] of sampleByPack) {
        let first = null;
        let second = null;
        try {
          first = buildProceduralModel(asset.id, { primaryColor: asset.defaultColors.primary, secondaryColor: asset.defaultColors.secondary, accentColor: asset.defaultColors.accent });
          second = buildProceduralModel(asset.id, { primaryColor: asset.defaultColors.primary, secondaryColor: asset.defaultColors.secondary, accentColor: asset.defaultColors.accent });
          if (signature(first) !== signature(second)) deterministic.push(pack);
        } catch (error) { deterministic.push(`${pack}: ${error.message}`); }
        finally { if (first) disposeModel(first); if (second) disposeModel(second); }
      }
      return { failures, meshCount: meshes, maxMeshes, maxVertexCount, formsChecked: forms.size, variantsDiffer, crossFormCollisions, biomeGroupsChecked: biomeGroups.size, deterministic };
    }, { timeout: 180000 });
    assert(geometryResult.failures.length === 0, `Geometry failures (${geometryResult.failures.length}): ${JSON.stringify(geometryResult.failures.slice(0, 12))}`);
    assert(geometryResult.variantsDiffer.length === 0, `Variants did not change geometry: ${geometryResult.variantsDiffer.slice(0, 12).join(', ')}`);
    assert(geometryResult.crossFormCollisions.length === 0, `Cross-form geometry collisions: ${JSON.stringify(geometryResult.crossFormCollisions.slice(0, 12))}`);
    assert(geometryResult.deterministic.length === 0, `Repeat builds differ: ${geometryResult.deterministic.join(', ')}`);

    const uiResult = await page.evaluate(async () => {
      const expectedPacks = ['nature', 'animals', 'objects', 'characters'];
      const formsByPack = Object.fromEntries(expectedPacks.map(pack => [pack, [...new Set(ASSET_CATALOG.filter(a => a.pack === pack).map(a => a.form))]]));
      const cardIds = () => [...document.querySelectorAll('#asset-list .asset-card')].map(el => el.id);
      const renderedForms = [];
      for (const pack of expectedPacks) {
        for (const form of formsByPack[pack]) {
          const asset = ASSET_CATALOG.find(a => a.pack === pack && a.form === form);
          selectAsset(asset.id);
          const box = new THREE.Box3().setFromObject(currentModelGroup);
          const size = box.getSize(new THREE.Vector3());
          if (box.isEmpty() || ![size.x, size.y, size.z].every(n => Number.isFinite(n) && n > 0)) throw new Error(`camera/render sample invalid: ${asset.id}`);
          if (camera.position.distanceTo(controls.target) <= 0) throw new Error(`camera not fitted: ${asset.id}`);
          for (const state of ['idle', 'walk', 'jump', 'action', 'spin']) {
            animateProceduralModel(currentModelGroup, state, 1.25);
            currentModelGroup.updateMatrixWorld(true);
          }
          animateProceduralModel(currentModelGroup, 'idle', 0);
          renderer.render(scene, camera);
          renderedForms.push(asset.id);
        }
      }

      const pageOne = cardIds();
      if (typeof setAssetPage === 'function') {
        setAssetPage(2);
        const pageTwo = cardIds();
        if (!pageOne.length || !pageTwo.length || pageOne.join('|') === pageTwo.join('|')) throw new Error('pagination did not change the displayed cards');
        setAssetPage(1);
      }
      showExpansionAssets();
      const input = document.getElementById('search-input');
      if (!input) throw new Error('search input is missing');
      input.value = 'tundra'; input.dispatchEvent(new Event('input', { bubbles: true }));
      const searchCount = cardIds().length;
      const searchResultCount = getFilteredAssets().length;
      if (searchResultCount !== 100 || searchCount !== 72 || cardIds().some(id => ASSET_CATALOG.find(a => a.id === id)?.biome !== 'tundra')) throw new Error(`search did not filter expansion catalog to tundra (results ${searchResultCount}, visible ${searchCount})`);
      input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true }));
      const categoryButton = document.querySelector('.cat-btn[data-cat="characters"]');
      if (categoryButton) categoryButton.click();
      const categoryCount = cardIds().length;
      const categoryResultCount = getFilteredAssets().length;
      if (categoryResultCount !== 25 || categoryCount !== 25 || cardIds().some(id => ASSET_CATALOG.find(a => a.id === id)?.category !== 'characters')) throw new Error(`category filter did not filter expansion catalog (results ${categoryResultCount}, visible ${categoryCount})`);
      if (typeof setCategory === 'function') setCategory('all');
      return { renderedForms, searchCount, searchResultCount, categoryCount, categoryResultCount, pageOneCount: pageOne.length };
    }, { timeout: 180000 });
    assert(uiResult.renderedForms.length === 100, `Rendered ${uiResult.renderedForms.length} forms, expected 100`);

    const loadout = await page.evaluate(() => {
      const hero = ASSET_CATALOG.find(a => a.pack === 'characters');
      const pet = ASSET_CATALOG.find(a => a.pack === 'animals' && a.category === 'pets');
      const item = ASSET_CATALOG.find(a => a.pack === 'objects' && a.category === 'items');
      if (!hero || !pet || !item) throw new Error('Could not find an expansion hero, pet, and equippable item');
      selectAsset(hero.id);
      setEquippedItem(item.id);
      setEquippedPet(pet.id);
      const slot = item.equipSlot || (item.id.startsWith('item_shield_') ? 'shield' : item.id === 'item_crown' ? 'head' : item.id === 'item_bow' ? 'left' : 'right');
      const socketName = ({ right: 'WeaponSocket', left: 'LeftWeaponSocket', head: 'HeadSocket', shield: 'ShieldSocket' })[slot];
      const socket = currentModelGroup.getObjectByName(socketName);
      const attached = !!socket && socket.children.some(child => child.userData.assetId === item.id);
      return { hero: hero.id, pet: pet.id, item: item.id, itemName: item.name, attached, petVisible: !!companionPetGroup };
    });
    assert(loadout.attached, `Expansion item ${loadout.item} did not attach to its character socket`);
    assert(loadout.petVisible, `Expansion pet ${loadout.pet} did not spawn with its character`);
    const downloadSummary = [];
    for (const [name, extension] of [['exportToOBJ', '.obj'], ['saveStudioImage', '.png'], ['downloadStarterGameHTML', '.html']]) {
      const pending = page.waitForEvent('download', { timeout: 30000 });
      await page.evaluate(fn => window[fn](), name);
      const download = await pending;
      const target = path.join(OUTPUT_DIR, download.suggestedFilename());
      await download.saveAs(target);
      const size = fs.statSync(target).size;
      assert(size > 100, `${name} produced a small/empty artifact (${size} bytes)`);
      assert(target.endsWith(extension), `${name} produced unexpected extension: ${target}`);
      downloadSummary.push({ function: name, file: path.basename(target), extension, bytes: size });
      if (extension === '.obj') {
        const obj = fs.readFileSync(target, 'utf8');
        assert(/^v /m.test(obj) && /^f /m.test(obj), 'OBJ is missing vertex or face data');
      }
      if (extension === '.png') {
        const png = fs.readFileSync(target);
        assert(png.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])), 'PNG signature is invalid');
      }
      if (extension === '.html') {
        const html = fs.readFileSync(target, 'utf8');
        assert(html.includes(loadout.hero) && html.includes(loadout.item) && html.includes(loadout.pet), 'Starter game HTML did not include the expansion hero, item, and pet');
        const game = await browser.newPage({ viewport: { width: 1280, height: 800 } });
        game.on('pageerror', error => pageErrors.push(`game: ${error.message}`));
        const instrumentedHTML = html.replace('const keys = {};', 'window.__polyforgeProbe = { player, pet, scene };\n        const keys = {};');
        assert(instrumentedHTML !== html, 'Could not install game interaction probe');
        await game.setContent(instrumentedHTML, { waitUntil: 'domcontentloaded' });
        await game.waitForFunction(() => !!document.querySelector('canvas'), { timeout: 30000 });
        const gameState = await game.evaluate(itemId => ({
          canvas: !!document.querySelector('canvas'),
          title: document.querySelector('#hud h1')?.textContent || '',
          renderSize: [document.querySelector('canvas').width, document.querySelector('canvas').height],
          itemAttached: !!window.__polyforgeProbe?.player?.getObjectByName('WeaponSocket')?.children.some(child => child.userData.assetId === itemId),
          petSpawned: !!window.__polyforgeProbe?.pet?.userData?.assetId
        }), loadout.item);
        assert(gameState.canvas && gameState.renderSize.every(value => value > 0), 'Exported game did not render a canvas');
        assert(gameState.title.includes(loadout.itemName), 'Exported game HUD does not identify the expansion item loadout');
        assert(gameState.petSpawned, 'Exported game did not instantiate its expansion pet');
        assert(gameState.itemAttached, 'Exported game did not attach its expansion item');
        const beforeMove = await game.evaluate(() => window.__polyforgeProbe.player.position.toArray());
        await game.keyboard.down('KeyW');
        await game.waitForTimeout(220);
        await game.keyboard.up('KeyW');
        const afterMove = await game.evaluate(() => window.__polyforgeProbe.player.position.toArray());
        assert(Math.abs(afterMove[2] - beforeMove[2]) > 0.08, 'Exported game keyboard movement did not move the hero');
        await game.keyboard.down('Space');
        await game.waitForTimeout(120);
        await game.keyboard.up('Space');
        const afterJump = await game.evaluate(() => window.__polyforgeProbe.player.position.y);
        assert(afterJump > 0.05, 'Exported game jump input did not move the hero upward');
        await game.close();
      }
    }

    const summary = {
      scope: 'Mechanical validation of configurations. Numerical differences do not certify distinct visual models.',
      catalog: catalogResult,
      geometry: { checkedMeshes: geometryResult.meshCount, maxMeshesPerModel: geometryResult.maxMeshes, forms: geometryResult.formsChecked, crossFormBiomeGroups: geometryResult.biomeGroupsChecked },
      ui: { renderedForms: uiResult.renderedForms.length, searchMatches: uiResult.searchCount, categoryMatches: uiResult.categoryCount },
      uiFilterTotals: { searchResults: uiResult.searchResultCount, categoryResults: uiResult.categoryResultCount },
      exportedLoadout: loadout,
      artifacts: downloadSummary,
      pageErrors,
      remoteRequests
    };
    fs.writeFileSync(path.join(OUTPUT_DIR, 'validacao-1126.json'), `${JSON.stringify({ ...summary, failures: [], offline: { remoteRequestsBlocked: remoteRequests.length } }, null, 2)}\n`);
    console.log(JSON.stringify(summary, null, 2));
    assert(pageErrors.length === 0, `Browser page errors: ${pageErrors.join('; ')}`);
    assert(remoteRequests.length === 0, `Unexpected external requests: ${remoteRequests.join(', ')}`);
  } finally {
    await browser.close();
  }
})().catch(error => {
  console.error(error.stack || error);
  process.exit(1);
});
