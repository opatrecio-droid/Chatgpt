function createAnimalsPack(biomes) {
  const forms = [
    ['lobo','Lobo','🐺','quadruped','canid',1],['raposa','Raposa','🦊','quadruped','canid',0.78],
    ['veado','Veado','🦌','quadruped','antler',1],['elefante','Elefante','🐘','quadruped','trunk',1.45],
    ['girafa','Girafa','🦒','quadruped','longneck',1.2],['cavalo','Cavalo','🐎','quadruped','mane',1.08],
    ['urso','Urso','🐻','quadruped','bear',1.3],['coelho','Coelho','🐇','quadruped','hare',0.7],
    ['gato','Gato','🐈','quadruped','feline',0.75],['macaco','Macaco','🐒','biped','primate',0.82],
    ['coruja','Coruja','🦉','bird','owl',0.95],['aguia','Águia','🦅','bird','raptor',1.08],
    ['flamingo','Flamingo','🦩','bird','longleg',1],['pinguim','Pinguim','🐧','bird','penguin',0.82],
    ['pato','Pato','🦆','bird','waterfowl',0.8],['borboleta','Borboleta','🦋','insect','butterfly',0.65],
    ['besouro','Besouro','🪲','insect','beetle',0.7],['aranha','Aranha-caçadora','🕷️','insect','spider',0.68],
    ['libelula','Libélula','🪰','insect','dragonfly',0.62],['peixe','Peixe','🐠','fish','fish',0.82],
    ['tubarao','Tubarão','🦈','fish','shark',1.18],['tartaruga','Tartaruga','🐢','reptile','turtle',0.9],
    ['crocodilo','Crocodilo','🐊','reptile','crocodile',1.12],['sapo','Sapo','🐸','reptile','frog',0.68],
    ['serpente','Serpente','🐍','snake','snake',0.9]
  ];
  const biomeNames = ['da Floresta','do Deserto','da Tundra','do Pântano','da Savana','do Oceano','Vulcânico','de Cristal','da Selva','do Céu'];
  const shape = [
    [1,1,1],[1.16,.88,1.08],[1.13,1.12,.94],[.96,1.08,1.12],[1.25,1.22,.92],[.93,1.06,1.16],[1.13,.93,1.02],[.87,1.16,.94],[.95,1.04,1.08],[1.03,1.13,.95]
  ];
  const assets=[];
  for (let fi=0;fi<forms.length;fi++) for (let bi=0;bi<10;bi++) {
    const f=forms[fi], b=biomes[bi], profile=shape[bi];
    assets.push({id:`petx_${f[0]}_${b.id}`,name:`${f[1]} ${biomeNames[bi]}`,category:'pets',categoryLabel:'Animais',icon:f[2],description:`${f[1]} com anatomia adaptada ao bioma ${b.name.toLowerCase()}.`,defaultColors:{primary:b.colors.primary,secondary:b.colors.secondary,accent:b.colors.accent},roughness:.78,metalness:.02,emissive:bi===7?.12:0,biome:b.id,form:f[0],variant:bi,seed:1201+fi*37+bi*101,pack:'animals'});
  }
  function build(asset,kit) {
    const {root,mat,sphere,box,cylinder,cone,torus,tube,group}=kit;
    const idx=asset.variant, form=forms.find(x=>x[0]===asset.form), type=form[3], kind=form[4], size=form[5], p=shape[idx];
    const body=mat.primary, trim=mat.secondary, bright=mat.accent, dark=mat.dark;
    const climate=[1,1.12,.88,1.04,1.06,1.15,1.08,.94,1.02,.91][idx];
    const Y=[1,1.08,.94,1.03,1.08,.95,.98,1.12,1.03,1.16][idx];
    const eye=(x,y,z,r=.075,parent=root)=>{sphere(r,dark,x,y,z,1,1,1,parent);sphere(r*.43,mat.light,x+(x<0?-.025:.025),y+.018,z+.043,1,1,1,parent);};
    const limb=(x,z,len,r=.105,material=body,label='')=>{const g=group(label,x,.72,z);cylinder(r*.72,r,len,material,0,-len/2,0,0,0,0,g);sphere(r*.92,material,0,-len,0,.96,.8,.96,g);return g;};
    const tail=(x,y,z,len,r=.09,material=body,parent=root)=>tube([[x,y,z],[x*.9,y+.08,z-len*.35],[x*.7,y+.15,z-len*.72],[x*.5,y+.18,z-len]],r,r*.48,material,parent);
    const ears=(parent,long=false)=>{const h=long?.48:.22;for(const x of [-.22,.22])cone(.13,h,trim,x,.2+h*.35,-.04,0,0,x*-.3,parent);};
    const fourLegs=(height=.48,r=.13,parent=root)=>{for(const x of [-.23*size,.23*size])for(const z of [-.30*size,.30*size]){const g=group((x<0?'left':'right')+'Leg',x,.86,z,parent);sphere(r*1.12,body,0,0,0,1,1,1,g);cylinder(r*.75,r,height,body,0,-height/2,0,0,0,0,g);sphere(r,body,0,-height,0,1,.68,1,g);box(r*1.5,.08,r*1.8,trim,0,-height-.03,.05,0,0,0,g);}};
    const quadruped=()=>{
      const torso=group('torso');
      const stocky=idx===2||idx===6?1.13:1; sphere(.47*size,body,0,1.02,0,.9*p[0]*stocky,.78*p[1],1.28*p[2],torso);
      let hy=1.28, hz=.78*size, headY=1.43;
      if(kind!=='longneck')sphere(.19*size,body,0,1.24,.48*size,1,1.3,1,torso);
      if(kind==='longneck'){cylinder(.17,.23,.83*Y,body,0,1.48,.56,Math.PI/10,0,0,torso);hy=1.75;headY=2.02;hz=.91;}
      const head=group('head',0,headY,hz,torso);
      sphere((kind==='trunk'?.27:.31)*size,body,0,0,0,.93,.94,1.02,head);
      if(kind==='trunk'){tube([[0,-.12,.23],[0,-.48,.48],[0,-.68,.4],[0,-.7,.15]],.13,.075,body,head);}
      else {const muzzle=kind==='canid'||kind==='feline'||kind==='bear'||kind==='hare';sphere(muzzle?.18:.12,trim,0,-.12,.25,muzzle?1:.8,.75,1.25,head);}
      const faceRadius=.31*size;
      eye(-faceRadius*.62,.04,faceRadius*.79,.065,head);eye(faceRadius*.62,.04,faceRadius*.79,.065,head);
      if(kind==='longneck')for(const side of [-1,1])sphere(.105,trim,side*faceRadius*.86,.12,-.04,1.2,.5,.7,head);
      if(kind==='antler'){for(const x of [-.2,.2]){cylinder(.045,.065,.38,trim,x,.36,-.02,0,0,x*.4,head);for(const s of [-1,1])cylinder(.025,.035,.22,trim,x+s*.1,.48,-.02,0,0,s*.5,head);}}
      if(kind==='mane'){for(let i=0;i<5;i++)cone(.15,.38,trim,-.24+i*.12,.11,-.12,Math.PI/2,0,0,head);}
      if(kind==='hare'){ears(head,true);sphere(.13,bright,0,-.52,-.57,1,1,1,head);}
      else if(kind==='feline'||kind==='canid'||kind==='bear'){ears(head,false);if(kind==='bear')sphere(.16,bright,0,-.39,-.55,1,1,1,head);}
      if(kind==='longneck')for(let x of [-.18,.18]){sphere(.07,trim,x,1.1,.56,1,1,1,torso);sphere(.055,trim,x,1.4,.42,1,1,1,torso);}
      const legH=(kind==='hare'?.58:.52)*Y*(idx===9?1.13:1);
      fourLegs(legH,kind==='trunk'?.19:.115,torso);
      if(kind!=='hare')tail(kind==='feline'?.22*size:0,1,-.42*size,kind==='feline'?.54:.48,.075,trim,torso);
      if(kind==='trunk'){
        for(const x of [-1,1])sphere(.28,trim,x*.37,.03,-.12,.66,1.05,.3,head);
        for(const x of [-.22,.22])cone(.105,.48,mat.light,x,-.26,.33,Math.PI/2,0,x*-.18,head);
      }
    };
    if(type==='quadruped') quadruped();
    else if(type==='biped'){
      // Upright monkey: long arms, grasping feet, a face muzzle, and a curled tail.
      const torso=group('torso');
      sphere(.34*size,body,0,1.08,0,.95*p[0],1.12*p[1],.82*p[2],torso);
      const head=group('head',0,1.57,.2,torso);sphere(.27*size,body,0,0,0,1,1,.95,head);
      sphere(.18,trim,0,-.1,.17,1,.72,.85,head);eye(-.13,.06,.2,.07,head);eye(.13,.06,.2,.07,head);
      for(const x of [-.29,.29])sphere(.12,body,x,.02,-.01,1,.9,.65,head);
      for(const x of [-1,1]){const arm=group(x<0?'leftArm':'rightArm',x*.34,1.38,.02,torso);tube([[0,0,0],[x*.18,-.22,.04],[x*.28,-.48,.12],[x*.3,-.66,.2]],.105,.07,body,arm);sphere(.105,trim,x*.3,-.67,.2,1,1,1,arm);const leg=group(x<0?'leftLeg':'rightLeg',x*.2,.78,0,torso);tube([[0,0,0],[x*.04,-.27,.12],[x*.08,-.48,.25]],.13,.1,body,leg);sphere(.13,trim,x*.08,-.5,.34,1,.55,1.35,leg);}
      tube([[0,1.03,-.25],[0,1.16,-.56],[.08,1.05,-.86],[.18,.88,-.95]],.06,.035,body,torso);
    }
    else if(type==='bird'){
      const peng=kind==='penguin', birdScale=size;
      sphere(.43*birdScale,body,0,1.0,0,.85*p[0],1.05*p[1],.83*p[2]);
      sphere(.27*birdScale,body,0,1.55,.2,.95,1,.95);eye(-.18,1.61,.42);eye(.18,1.61,.42);
      const beak=kind==='owl'?.12:.17;cone(beak,.35,bright,0,1.48,.59,Math.PI/2);
      if(kind==='owl'){for(const x of [-.18,.18])cone(.15,.4,trim,x,1.86,.12,0,0,x*.4);}
      const wingLen=idx===9||idx===7?1.05:.7;
      for(const x of [-1,1]){const w=group(x<0?'leftWing':'rightWing',x*.14,1.25,0);sphere(.22,trim,x*.23,0,-.02,1.6,.72,wingLen*.8,w);for(let j=0;j<3;j++)cone(.11,.36,body,x*(.23+j*.07),-.02,-.12-j*.12,0,0,x*.36,w);}
      if(kind==='longleg'){for(const x of [-.18,.18]){cylinder(.045,.05,1.0,trim,x,.5,0);sphere(.12,bright,x,0,.1,1,.36,1);}}
      else {for(const x of [-.18,.18]){cylinder(.06,.07,.42,trim,x,.45,0);for(let j=-1;j<=1;j++)cone(.055,.22,bright,x+j*.08,.18,.12,Math.PI/2,0,j*.3);}}
      for(let j=0;j<3;j++)cone(.12,.38,trim,(j-1)*.12,.94,-.62,-Math.PI/2,0,(j-1)*.1);
      if(peng){sphere(.29,mat.light,0,1.02,.36,.75,1,.3);}
    } else if(type==='insect'){
      const spider=kind==='spider', butterfly=kind==='butterfly', dragon=kind==='dragonfly';
      sphere(.28,body,0,1.1,.2,.88,.85,1.1);sphere(.34,body,0,1.08,-.34,spider?1.1:.78,.85,1.28);
      if(!spider){sphere(.21,body,0,1.12,-.78,.8,.74,1.12);}
      eye(-.14,1.19,.38,.07);eye(.14,1.19,.38,.07);
      if(spider){for(const x of [-1,1])for(let n=0;n<4;n++){const z=.35-n*.28;const g=group(x<0?'leftLeg':'rightLeg',x*.2,1.03,z);tube([[0,0,0],[x*.35,.12,.08],[x*.59,-.12,.22],[x*.78,-.25,.28]],.065,.04,trim,g);}}
      else for(const x of [-1,1])for(let n=0;n<3;n++){const z=.2-n*.34;const g=group(x<0?'leftLeg':'rightLeg',x*.19,1,z);tube([[0,0,0],[x*.22,-.16,.03],[x*.4,-.36,.12]],.055,.035,trim,g);}
      if(butterfly||dragon){for(const x of [-1,1])for(let pair=0;pair<2;pair++){
        const w=group(x<0?'leftWing':'rightWing',x*.12,1.36,.1-pair*.2);
        if(butterfly){sphere(.36,trim,x*.32,pair===0?.2:-.2,0,1.02,.98,.22,w);sphere(.085,bright,x*.39,pair===0?.2:-.2,.035,1,.8,.25,w);}
        else {sphere(.27,trim,x*.34,pair===0?.14:-.14,0,.38,.22,1.35,w);sphere(.035,bright,x*.46,pair===0?.14:-.14,.025,1,1,1,w);}
      }}
      else {const shell=mat.secondary;sphere(.37,shell,0,1.3,-.37,1.12,.52,1.12);for(const x of [-.19,.19])torus(.2,.025,bright,x,1.54,-.37,Math.PI/2);}
      if(kind==='beetle'){cone(.2,.34,bright,0,1.12,-.98,Math.PI/2);}
      for(const x of [-.1,.1])tube([[x,1.27,.36],[x*1.7,1.55,.48],[x*2,1.62,.65]],.035,.018,trim,root);
    } else if(type==='fish'){
      const shark=kind==='shark';sphere(.4*size,body,0,1.15,0,.8*p[0],.78*p[1],1.42*p[2]);
      sphere(.28,body,0,1.16,.78,.92,.75,1.0);eye(-.3,1.27,.82);eye(.3,1.27,.82);
      cone(.07,.35,mat.light,0,.91,.86,Math.PI/2);
      // Tail and paired fins preserve a fish-shaped silhouette in every biome.
      for(const x of [-1,1]){cone(.22,.58,trim,x*.39,1.14,-.05,0,0,x*.95);cone(.15,.42,bright,x*.23,.86,.22,0,0,x*.8);}
      cone(shark?.28:.2,shark?.62:.47,trim,0,1.53,-.25,Math.PI/2);
      cone(.22,.68,trim,0,1.17,-1.03,0,0,Math.PI/2);
      if(shark){for(let n=0;n<5;n++)box(.08,.045,.04,mat.light,-.12+n*.06,.93,.82,0,0,0);}
      else for(let n=0;n<3;n++)sphere(.09,bright,-.18+n*.18,1.31,.3,.7,.7,.7);
    } else if(type==='reptile'){
      if(kind==='frog'){
        sphere(.43,body,0,.83,0,1.05,.76,1.0);sphere(.27,body,0,1.25,.35,1.05,.8,.85);
        for(const x of [-.2,.2]){sphere(.15,body,x,1.49,.44);eye(x,1.51,.57,.07);}
        for(const x of [-1,1]){
          const fore=group(x<0?'leftArm':'rightArm',x*.3,.64,.22);tube([[0,0,0],[x*.1,-.19,.08],[x*.13,-.37,.18]],.09,.07,body,fore);sphere(.1,bright,x*.13,-.38,.24,.85,.3,1.1,fore);
          const hind=group(x<0?'leftLeg':'rightLeg',x*.38,.58,-.18);tube([[0,0,0],[x*.16,-.1,.16],[x*.27,-.34,.39],[x*.3,-.49,.49]],.18,.105,body,hind);sphere(.15,body,x*.3,-.5,.52,1,.55,1.4,hind);
          for(let toe=-1;toe<=1;toe++)sphere(.045,bright,x*.3+toe*.07,-.52,.62,.8,.45,1.2,hind);
        }
        for(const x of [-.32,.32]){sphere(.12,bright,x,.85,.48,.75,.28,.55);}
      } else if(kind==='turtle'){
        sphere(.46,body,0,.95,0,1.16,.54,1.2);sphere(.44,trim,0,1.26,-.05,1.05,.76,1.13);sphere(.17,body,0,1.05,.65);eye(-.11,1.14,.77);eye(.11,1.14,.77);
        for(const x of [-.42,.42])for(const z of [-.36,.38]){sphere(.14,body,x,.66,z,1,.8,1.1);}
        for(let x=-1;x<=1;x++)for(let z=-1;z<=1;z++)sphere(.12,bright,x*.2,1.51,z*.2-.04,.85,.12,.85);
      } else {
        sphere(.38,body,0,.8,0,.83, .63,1.52*p[2]);sphere(.27,body,0,1.08,.55,.92,.78,1);eye(-.18,1.17,.78);eye(.18,1.17,.78);
        for(const x of [-.35,.35]){limb(x,-.35,.4,.13,body,x<0?'leftLeg':'rightLeg');limb(x,.38,.4,.13,body,x<0?'leftLeg':'rightLeg');}
        if(kind==='crocodile'){for(let n=0;n<6;n++)cone(.1,.24,trim,-.25+n*.1,1.16,-.52-n*.13,0,0,0);sphere(.21,body,0,.99,1.04,1.12,.5,2.25);sphere(.16,trim,0,.87,1.08,1.08,.28,2.05);}
        tail(0,.8,-.48,kind==='crocodile'?1.15:.68,.1,body);
      }
    } else if(type==='snake'){
      // Three broad coils and a raised head make the limbless form unmistakable.
      for(let i=0;i<3;i++)torus(.38+i*.04,.12,body,0,.53+i*.035,-.15,Math.PI/2,0,0);
      tube([[0,.65,.14],[0,.79,.52],[0,1.05,.72],[0,1.34,.72]],.12,.14,body,root);
      sphere(.2,body,0,1.42,.72,1.05,.75,1.1);eye(-.14,1.48,.87);eye(.14,1.48,.87);
      for(const x of [-.14,.14])sphere(.05,bright,x,1.39,.89,.6,1,.45);
      tube([[0,1.3,.9],[0,1.24,1.07]],.025,.018,bright,root);
      for(let i=0;i<5;i++)sphere(.075,trim,Math.sin(i*1.2)*.28,.65,-.42+i*.13,.7,.45,.9);
    }
    // Biome morphology additions: crest, plates, mane ridge, or a mineral/reef collar.
    if(idx===1||idx===4){for(let n=0;n<3;n++)cone(.12,.3,bright,0,1.42+n*.06,-.2-n*.2,Math.PI/2);}
    if(idx===2){sphere(.54,trim,0,.92,-.08,1.08,.9,1.12);}
    if(idx===3||idx===8){for(let n=0;n<3;n++)sphere(.11,bright,Math.sin(n*2)*.27,1.32,-.4+n*.25,.75,.75,.7);}
    if(idx===5){torus(.57,.055,bright,0,.7,0,Math.PI/2);}
    if(idx===6){for(let n=0;n<3;n++)cone(.09,.27,bright,-.28+n*.28,1.55,-.1-n*.17,Math.PI/2);}
    if(idx===7){for(let n=0;n<3;n++)cone(.1,.25,bright,-.25+n*.25,1.38,-.22-n*.18,Math.PI/2);}
    if(idx===9){for(let x of [-.28,.28]){const w=group(x<0?'leftWing':'rightWing',x,1.15,-.1);sphere(.3,bright,x*1.8,.1,-.2,.9,.22,1.1,w);}}
    // Habitat proportions affect every body plan, including insects and reptiles.
    // Scale mesh dimensions and joint offsets locally; keep the asset root at unit scale.
    const habitat=new kit.THREE.Vector3(p[0],p[1],p[2]);
    root.traverse(node=>{if(node!==root){node.position.multiply(habitat);if(node.isMesh)node.scale.multiply(habitat);}});
  }
  return {assets,build};
}
