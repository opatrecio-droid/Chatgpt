function createCharactersPack(biomes) {
  const forms = [
    ['Cavaleiro de Placas','guard','melee'],['Maga Astral','mage','magic'],['Batedor da Mata','scout','bow'],['Ladino Mascarado','rogue','melee'],['Oráculo Solar','priest','magic'],
    ['Ferreiro de Campo','smith','melee'],['Alquimista Errante','alchemist','magic'],['Corsário','pirate','gun'],['Samurai Errante','samurai','melee'],['Berserker do Norte','berserker','melee'],
    ['Mineiro de Cristal','miner','melee'],['Cozinheira de Batalhão','cook','melee'],['Cronista','scholar','magic'],['Trovador','bard','magic'],['Guardião de Colheita','farmer','bow'],
    ['Pescadora de Marés','fisher','bow'],['Piloto Orbital','pilot','gun'],['Louva-a-Deus Duelista','mantis','melee'],['Sentinela de Pedra','golem','melee'],['Xamã Cogumelo','fungus','magic'],
    ['Escamado das Dunas','reptile','bow'],['Falconeiro dos Ventos','avian','bow'],['Nômade Cacto','cactus','melee'],['Mergulhador Abissal','diver','gun'],['Autômato de Corda','clockwork','melee']
  ];
  const bioNames = {forest:'da Floresta',desert:'do Deserto',tundra:'da Tundra',swamp:'do Pântano',savanna:'da Savana',ocean:'do Oceano',volcanic:'Vulcânica',crystal:'de Cristal',jungle:'da Selva',sky:'dos Céus'};
  const assets=[];
  for (let f=0;f<forms.length;f++) for (let v=0;v<biomes.length;v++) {
    const [title,form,combat]=forms[f], b=biomes[v];
    assets.push({id:`charx_${String(f+1).padStart(2,'0')}_${String(v+1).padStart(2,'0')}`,name:`${title} ${bioNames[b.id]||b.name}`,category:'characters',categoryLabel:'Personagens',icon:['♞','✦','➶','◈','☼','⚒','⚗','☠','⚔','♜','⛏','♨','▤','♫','♧','⚓','◉','♧','⬟','☘','♢','➤','♧','◌','⚙'][f],description:`${title} com silhueta e equipamento próprios, adaptado ao bioma ${b.name}.`,defaultColors:{...b.colors},roughness:.74,metalness:form==='golem'||form==='clockwork'?.52:.12,emissive:form==='mage'||form==='fungus'?.12:0,biome:b.id,form,variant:v,seed:41001+f*37+v*101,pack:'characters',combatType:combat});
  }

  function build(asset,kit) {
    const {THREE,root,mat,group}=kit;
    let activeParent=root;
    const sphere=(r,material,x=0,y=0,z=0,sx=1,sy=1,sz=1,parent=activeParent)=>kit.sphere(r,material,x,y,z,sx,sy,sz,parent);
    const box=(w,h,d,material,x=0,y=0,z=0,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1,parent=activeParent)=>{const m=kit.box(w,h,d,material,x,y,z,rx,ry,rz); if(parent!==root) parent.add(m); m.scale.set(sx,sy,sz); return m;};
    const cylinder=(rt,rb,h,material,x=0,y=0,z=0,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1,parent=activeParent)=>kit.add(new THREE.CylinderGeometry(rt,rb,h,8),material,x,y,z,rx,ry,rz,sx,sy,sz,parent);
    const cone=(r,h,material,x=0,y=0,z=0,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1,parent=activeParent)=>kit.add(new THREE.ConeGeometry(r,h,7),material,x,y,z,rx,ry,rz,sx,sy,sz,parent);
    const torus=(r,tube,material,x=0,y=0,z=0,rx=0,ry=0,rz=0,parent=activeParent)=>kit.add(new THREE.TorusGeometry(r,tube,6,10),material,x,y,z,rx,ry,rz,1,1,1,parent);
    const v=asset.variant, form=asset.form;
    const p=mat.primary,s=mat.secondary,a=mat.accent,d=mat.dark,l=mat.light,skin=mat.skin;
    const limb=(name,x,y,z,material,r=.095,len=.36)=>{
      const g=group(name,x,y,z); cylinder(r*.83,r,len,material,0,-len/2,0,0,0,0,1,1,1,g); sphere(r,material,0,0,0,1,1,1,g); return g;
    };

    // Anatomy pivots are shared by the animator, while the recipe controls each silhouette.
    const wide=['guard','samurai','berserker','golem'].includes(form),slim=['rogue','scout','scholar','avian'].includes(form);
    const torsoW=wide?.48:slim?.31:.38, torsoH=form==='golem'?.66:.55;
    const torso=group('torso',0,1.03,0);
    if(form==='golem') { box(torsoW,torsoH,.31,p,0,0,0,0,.12,.02,1,1,1,torso); box(.52,.12,.36,s,0,.19,0,0,0,0,1,1,1,torso); }
    else if(form==='mantis') { sphere(.21,p,0,0,0,.78,1.35,.65,torso); box(.32,.18,.27,s,0,-.17,0,0,0,0,1,1,1,torso); }
    else if(form==='fungus') { sphere(.21,p,0,-.05,0,.8,1.25,.72,torso); sphere(.34,a,0,.25,0,1,.36,1,torso); }
    else if(form==='cactus') { cylinder(.15,.23,.55,p,0,-.01,0,0,0,0,1,1,1,torso); for(let q=-1;q<=1;q++) sphere(.025,a,q*.12,.04,.17,1,1,.75,torso); }
    else if(form==='clockwork') { cylinder(.23,.28,.47,p,0,0,0,Math.PI/2,0,0,1,1,1,torso); torus(.17,.035,a,0,.02,.16,Math.PI/2,0,0,torso); }
    else box(torsoW,torsoH,.28,p,0,0,0,0,form==='reptile'?.05:0,0,1,1,1,torso);
    // Coat, armor, robe, apron or harness changes the central profile.
    if(['mage','priest','scholar','bard','alchemist'].includes(form)) cone(.38,.52,s,0,-.22,0,0,0,0,1,1,1,torso);
    if(['smith','cook','farmer','fisher','miner'].includes(form)) box(.36,.34,.035,a,0,-.04,.17,0,0,0,1,1,1,torso);
    if(['guard','samurai','berserker'].includes(form)) { box(.43,.12,.32,s,0,.16,0,0,0,0,1,1,1,torso); if(form==='samurai') { box(.58,.09,.3,a,0,.24,0,0,0,0,1,1,1,torso); } }
    if(form==='alchemist') {
      torus(.19,.035,a,0,-.22,.02,0,0,0,torso);
      for(let i=0;i<3;i++) { cylinder(.035,.045,.12,i===1?a:s,(-1+i)*.1,-.22,.12,0,0,0,1,1,1,torso); sphere(.045,l,(-1+i)*.1,-.15,.12,1,.6,1,torso); }
      box(.16,.06,.025,d,0,-.1,-.17,0,0,0,1,1,1,torso);
    }
    if(form==='priest') {
      box(.1,.42,.04,a,0,.02,.16,0,0,0,1,1,1,torso);
      box(.22,.16,.04,s,0,-.24,.16,0,0,0,1,1,1,torso);
    }
    if(form==='bard') {
      sphere(.17,a,.22,-.1,.18,1.15,.78,.48,torso);
      box(.055,.34,.045,s,.29,.08,.16,0,0,-.18,1,1,1,torso);
      for(let i=0;i<3;i++) box(.008,.3,.012,l,.2+i*.025,.01,.205,0,0,0,1,1,1,torso);
    }
    if(form==='scholar') {
      box(.3,.38,.19,s,0,.04,-.2,0,0,0,1,1,1,torso);
      box(.23,.3,.045,l,0,.04,-.31,0,0,0,1,1,1,torso);
      box(.025,.33,.05,a,0,.04,-.34,0,0,0,1,1,1,torso);
    }
    if(form==='farmer') {
      box(.24,.27,.18,s,-.28,-.08,-.04,0,0,-.12,1,1,1,torso);
      for(let i=0;i<3;i++) cylinder(.012,.018,.22,a,-.34+i*.06,.17,-.04,0,0,0,1,1,1,torso);
    }
    if(form==='fisher') {
      box(.23,.25,.13,s,.27,-.1,-.05,0,0,.1,1,1,1,torso);
      torus(.09,.018,a,.27,-.08,-.13,Math.PI/2,0,0,torso);
      box(.25,.06,.025,l,0,.11,-.17,0,0,.06,1,1,1,torso);
    }
    // Head pivots and expressive face.
    const head=group('head',0,.4,0,torso); activeParent=head; const headMat=['golem','clockwork'].includes(form)?s:skin;
    sphere(form==='avian'?.19:.185,headMat,0,0,0,form==='golem'?1.2:1,1.08,.9,head);
    sphere(.034,l,-.067,.035,.151,1,1,1,head); sphere(.034,l,.067,.035,.151,1,1,1,head);
    sphere(.018,d,-.067,.035,.178); sphere(.018,d,.067,.035,.178);
    box(.105,.018,.02,d,0,-.075,.174);
    // Distinct headwear and species features.
    if(form==='mage') { cone(.22,.35,p,0,.25,0,0,0,0); torus(.17,.025,a,0,.08,0,Math.PI/2); }
    if(form==='alchemist') { cylinder(.15,.19,.08,s,0,.16,0); cone(.13,.2,p,0,.29,0); }
    if(form==='alchemist') {
      torus(.055,.014,s,-.07,.035,.17); torus(.055,.014,s,.07,.035,.17);
      box(.09,.018,.018,a,0,.035,.17);
    }
    if(form==='guard'||form==='samurai') { box(.4,.09,.35,s,0,.15,0); if(form==='samurai') { box(.07,.34,.08,a,-.13,.34,0,0,0,-.28); box(.07,.34,.08,a,.13,.34,0,0,0,.28); } }
    if(form==='berserker'||form==='reptile') { cone(.1,.28,a,-.14,.2,0,0,0,.22); cone(.1,.28,a,.14,.2,0,0,0,-.22); }
    if(form==='avian') { cone(.1,.27,a,0,-.03,.19,Math.PI/2); sphere(.06,p,0,.22,0,1.5,.65,1); }
    if(form==='fungus') { sphere(.31,a,0,.19,0,1,.35,1); for(let q=-1;q<=1;q++) sphere(.035,l,q*.13,.18,.19); }
    if(form==='clockwork') { torus(.14,.035,a,0,0,.08); cylinder(.03,.03,.28,s,.2,0,0,0,0,Math.PI/2); }
    if(form==='pirate') { cylinder(.17,.2,.055,d,0,.18,0); box(.42,.035,.3,d,0,.2,0); }
    if(form==='cook') { cylinder(.12,.15,.12,l,0,.2,0); cylinder(.13,.13,.15,l,0,.32,0); }
    if(form==='farmer') { cylinder(.22,.22,.035,a,0,.19,0); cylinder(.12,.14,.14,a,0,.27,0); for(let i=-1;i<=1;i++) cone(.028,.18,l,i*.08,-.22,.16,0,0,i*.16); }
    if(form==='fisher') { cylinder(.2,.2,.035,s,0,.19,0); cylinder(.12,.15,.12,s,0,.26,0); box(.3,.035,.22,a,0,.18,-.02); }
    if(form==='pilot') { sphere(.24,mat.light,0,.02,0,1,1,.62); box(.25,.055,.025,d,0,.04,.17); box(.12,.012,.012,a,0,.066,.19); }
    if(form==='cactus') { cone(.2,.25,s,0,.18,0); }
    if(form==='priest') { torus(.24,.025,a,0,.28,-.04,Math.PI/2); sphere(.055,l,0,.28,-.04); }
    activeParent=root;
    // Legs and segmented shins.
    const legMat=['golem','clockwork'].includes(form)?s:form==='cactus'?p:p, lowerLegs={};
    for(const side of [-1,1]) { const nm=side<0?'left':'right'; const hip=group(nm+'Leg',side*.14,.67,0); cylinder(.085,.105,.28,legMat,0,-.13,0,0,0,0,1,1,1,hip); const shin=group(nm+'Shin',0,-.28,0,hip); lowerLegs[nm]=shin; cylinder(.07,.09,.27,form==='guard'||form==='samurai'?s:legMat,0,-.13,0,0,0,0,1,1,1,shin); box(.17,.09,.23,d,0,-.29,.035,0,0,0,1,1,1,shin); }
    // Arms, forearms and recognizable tools/profession details.
    const hands={};
    for(const side of [-1,1]) { const nm=side<0?'left':'right', arm=group(nm+'Arm',side*(torsoW*.65),.19,0,torso); activeParent=arm; cylinder(.09,.115,.29,form==='mantis'?p:p,0,-.14,0); sphere(.095,skin,0,-.29,0); const fore=group(nm+'Forearm',0,-.29,0,arm); hands[nm]=fore; activeParent=fore; cylinder(.07,.09,.25,form==='guard'||form==='golem'?s:skin,0,-.12,0); sphere(.08,skin,0,-.25,0);
      if(form==='mantis') { cone(.06,.45,p,side*.04,-.12,.03,0,0,side*.4); }
      if(form==='clockwork') { cylinder(.06,.1,.2,a,0,-.18,0); }
      if(form==='smith'&&side>0) { cylinder(.04,.04,.42,s,0,-.18,0); box(.13,.12,.14,a,0,-.03,0); }
      if(form==='cook'&&side>0) { cylinder(.018,.018,.35,s,0,-.18,0); sphere(.07,a,0,-.04,0,1.2,.6,1); }
      if(form==='miner'&&side>0) { cylinder(.03,.035,.34,s,0,-.16,0); cone(.13,.14,a,0,.03,0); }
    }
    activeParent=root;
    // Biome-specific morphology and accessories alter the silhouette in every habitat.
    const variantRootStart=root.children.length;
    if(v===0) { // forest: branching antlers and leaf mantle
      for(const side of [-1,1]) { cylinder(.025,.04,.23,a,side*.2,1.62,0,0,0,side*.22); cone(.07,.13,s,side*.28,1.55,0); }
      for(let i=0;i<3;i++) sphere(.08,a,(i-1)*.15,1.1,.2,1,.5,1);
    } else if(v===1) { // desert: wrapped scarf and high sun veil
      torus(.2,.045,s,0,1.46,0); box(.45,.13,.28,a,0,1.68,-.02); box(.45,.11,.34,s,0,1.19,-.08);
    } else if(v===2) { // tundra: hood, fur collar and broad boots
      sphere(.28,s,0,1.47,-.12,.98,1,.34); torus(.24,.065,l,0,1.29,0); box(.38,.16,.32,s,0,.13,.02);
    } else if(v===3) { // swamp: reed crest and bulbous filter mask
      for(let i=-1;i<=1;i++) cylinder(.018,.03,.34,a,i*.12,1.65,-.04,0,0,i*.24);
      sphere(.14,s,0,1.38,.16,1,.8,.65); for(let i=-1;i<=1;i++) sphere(.035,a,i*.08,1.38,.26);
    } else if(v===4) { // savanna: tall crest and layered shoulder mantle
      for(let i=-2;i<=2;i++) cone(.055,.25,a,i*.07,1.68,0,0,0,i*.05);
      box(.58,.12,.34,s,0,1.23,0);
    } else if(v===5) { // ocean: fin crest, gills and webbed feet
      cone(.1,.34,a,0,1.69,-.04); for(const side of [-1,1]) for(let i=0;i<3;i++) box(.018,.07,.03,s,side*.2,1.38-i*.07,.12);
      torus(.13,.035,a,0,.48,0,Math.PI/2);
    } else if(v===6) { // volcanic: basalt horns and glowing lava seams
      for(const side of [-1,1]) cone(.09,.28,s,side*.17,1.64,-.02,0,0,side*.3);
      for(let i=0;i<3;i++) box(.035,.24,.025,a,-.1+i*.1,1.04,.16,0,0,(i-1)*.15);
    } else if(v===7) { // crystal: asymmetric geode crown and shoulder shard
      for(let i=0;i<4;i++) cone(.065,.22,a,(i-1.5)*.09,1.65,.02,0,0,(i%2?-.15:.15));
      cone(.15,.3,s,-.31,1.23,0,0,0,-.4);
    } else if(v===8) { // jungle: broad frond cape and climbing tail
      for(let i=-2;i<=2;i++) cone(.09,.34,a,i*.11,1.12,-.17,Math.PI/2,0,i*.25);
      const tail=group('tail',0,.84,-.14); activeParent=tail; cylinder(.055,.11,.45,form==='reptile'?p:a,0,-.15,-.21,Math.PI/2); activeParent=root;
    } else { // sky: feathered wings and wind streamers
      for(const side of [-1,1]) { const wing=group(side<0?'leftWing':'rightWing',side*.28,1.1,-.08); activeParent=wing; for(let i=0;i<4;i++) cone(.08,.34,i%2?s:a,side*.13,0,-i*.06,Math.PI/2,0,side*.35); activeParent=root; }
      for(const side of [-1,1]) box(.08,.35,.03,a,side*.23,1.05,-.22,0,0,side*.18);
    }
    // Preserve each add-on's rest position while putting it on the body pivot it decorates.
    // THREE.Group.attach retains world transforms, so biome geometry follows the rig afterward.
    const variantRoots=root.children.slice(variantRootStart);
    for(const node of variantRoots) {
      const y=node.position.y;
      const target=y>1.3?head:y<.6?lowerLegs[node.position.x>0?'right':'left']:torso;
      target.attach(node);
    }
    // Named attachment points are consumed by equipment and combat animation.
    const weapon=group('WeaponSocket',0,-.25,.11,hands.right); weapon.rotation.y=.25;
    const leftWeapon=group('LeftWeaponSocket',0,-.25,.11,hands.left); leftWeapon.rotation.y=-.25;
    const shield=group('ShieldSocket',-.03,-.2,.1,hands.left); const headSocket=group('HeadSocket',0,.29,0,head);
    root.userData.combatType=asset.combatType;
    if(!kit.config?.hideDefaultWeapon) {
      // A visible, grip-relative prop gives every profession's combat style a readable silhouette.
      const held=group('weaponGrip',0,-.23,.11,hands.right); activeParent=held;
      if(asset.combatType==='bow') { torus(.17,.022,s,0,.04,0,Math.PI/2); cylinder(.012,.012,.34,a,0,.04,.01,0,0,Math.PI/2); cylinder(.012,.012,.32,l,0,.05,.05,0,0,Math.PI/2); }
      else if(asset.combatType==='magic'&&form==='mage') { cylinder(.032,.045,.69,s,0,.22,0); sphere(.105,a,0,.59,0,1,1,1); torus(.13,.018,l,0,.59,0,Math.PI/2); }
      else if(asset.combatType==='magic'&&form==='alchemist') { cylinder(.025,.035,.2,s,0,.08,0); sphere(.09,a,0,.23,0,1,.8,1); torus(.055,.012,l,0,.33,0); }
      else if(asset.combatType==='magic'&&(form==='priest'||form==='scholar')) { box(.19,.26,.045,a,0,.18,0); box(.15,.22,.018,l,0,.18,.028); box(.025,.27,.052,s,0,.18,.055); }
      else if(asset.combatType==='magic'&&form==='bard') { sphere(.12,a,0,.1,0,1.1,.72,.5); box(.035,.25,.03,s,.1,.24,0,0,0,-.18); for(let i=0;i<3;i++) box(.006,.22,.008,l,i*.025,.14,.05); }
      else if(asset.combatType==='magic') { cylinder(.032,.045,.69,s,0,.22,0); sphere(.1,a,0,.59,0,1,1,1); torus(.12,.018,l,0,.59,0,Math.PI/2); }
      else if(asset.combatType==='gun') { box(.08,.22,.11,s,0,.08,0); cylinder(.035,.045,.22,d,0,.21,.02); box(.045,.13,.055,a,0,-.07,.01,-.18); sphere(.035,l,0,.13,.09); }
      else { cylinder(.024,.024,.25,d,0,.12,0); box(.105,.43,.028,s,0,.45,0,0,0,0,1,.78,1); cone(.055,.08,a,0,.7,0); box(.16,.035,.045,a,0,.23,0); }
      activeParent=root;
    }
    if(!kit.config?.hideDefaultShield && ['guard','samurai','berserker'].includes(form)) { const sh=group('shield',-.04,-.18,.08,hands.left); activeParent=sh; box(.25,.33,.07,s,0,0,0,0,0,.12); torus(.075,.018,a,0,0,.05); activeParent=root; }
  }
  return {assets,build};
}
