function createNaturePack(biomes) {
  const forms = [
    ['carvalho', 'Carvalho antigo', '🌳', 'Uma árvore de copa larga, tronco robusto e raízes expostas.'],
    ['pinheiro', 'Pinheiro alto', '🌲', 'Uma conífera em andares de ramos triangulares.'],
    ['palmeira', 'Palmeira curvada', '🌴', 'Uma palmeira de tronco inclinado e frondes arqueadas.'],
    ['baoba', 'Baobá', '🌳', 'Um baobá de tronco bojudo, copa compacta e raízes grossas.'],
    ['chorona', 'Salgueiro-chorão', '🌿', 'Uma árvore de copa pendente formada por longos ramos.'],
    ['mangue', 'Manguezal', '🌱', 'Um mangue com raízes aéreas que descem até o solo.'],
    ['bambu', 'Moita de bambu', '🎋', 'Uma touceira de colmos segmentados com folhas estreitas.'],
    ['cacto', 'Cacto saguaro', '🌵', 'Um cacto alto com braços laterais e espinhos.'],
    ['cogumelo', 'Cogumelo gigante', '🍄', 'Um cogumelo com haste, chapéu e pequenas pintas.'],
    ['flor', 'Flor solar', '🌼', 'Uma flor grande com pétalas radiais e folhas basais.'],
    ['samambaia', 'Samambaia', '🌿', 'Uma samambaia com frondes arqueadas e folíolos.'],
    ['suculenta', 'Roseta suculenta', '🪴', 'Uma roseta de folhas carnudas sobre um pequeno canteiro.'],
    ['lirio', 'Vitória-régia', '🪷', 'Folhas circulares flutuantes com uma flor central.'],
    ['coral', 'Coral-árvore', '🪸', 'Um coral ramificado que se ergue como uma árvore submarina.'],
    ['recife', 'Recife cerebral', '🪸', 'Um conjunto baixo de corais arredondados e sulcados.'],
    ['alga', 'Floresta de algas', '🌊', 'Hastes marinhas longas com lâminas onduladas.'],
    ['rochas', 'Monólitos erodidos', '🪨', 'Um agrupamento de pedras de alturas e formas diferentes.'],
    ['arco', 'Arco de pedra', '🪨', 'Um arco natural espesso sobre uma abertura transitável.'],
    ['cristais', 'Geodo cristalino', '💎', 'Um aglomerado de cristais prismáticos de vários tamanhos.'],
    ['vulcao', 'Cone vulcânico', '🌋', 'Um cone vulcânico aberto com cratera e lava visível.'],
    ['geyser', 'Gêiser', '♨️', 'Uma formação rochosa em torno de uma coluna de água.'],
    ['ilha', 'Ilha flutuante', '🏝️', 'Um pequeno diorama de ilha com massa de terra suspensa.'],
    ['cascata', 'Cascata', '💧', 'Uma queda de água escalonada entre rochas e vegetação.'],
    ['raizes', 'Arco de raízes', '🌱', 'Raízes grossas que se entrelaçam formando um portal.'],
    ['bonsai', 'Bonsai inclinado', '🌳', 'Uma árvore miniatura torcida crescendo sobre uma rocha.']
  ];

  const assets = [];
  for (let fi = 0; fi < forms.length; fi++) {
    const [form, baseName, icon, detail] = forms[fi];
    for (let bi = 0; bi < biomes.length; bi++) {
      const biome = biomes[bi];
      const name = `${baseName} ${biome.adjective}`;
      assets.push({
        id: `natx_${form}_${biome.id}`, name, category: 'nature', categoryLabel: 'Natureza',
        icon, description: `${detail} Versão ${biome.adjective.toLowerCase()} com escala e ornamentos adaptados ao bioma.`,
        defaultColors: { primary: biome.colors.primary, secondary: biome.colors.secondary, accent: biome.colors.accent },
        roughness: 0.82, metalness: 0.02, emissive: form === 'vulcao' || form === 'cristais' ? 0.1 : 0,
        biome: biome.id, form, variant: bi, seed: 17001 + fi * 101 + bi * 7, pack: 'nature'
      });
    }
  }

  function build(asset, kit) {
    const { primary: p, secondary: s, accent: a, dark: d, light: l, wood: w } = kit.mat;
    const f = asset.form;
    const v = asset.variant;
    const n = 0.82 + v * 0.035;
    const add = kit.add, sphere = kit.sphere, box = kit.box, cyl = kit.cylinder, cone = kit.cone, torus = kit.torus;
    const firstNewChild = kit.root.children.length;
    const ground = (rad, material = s, y = 0.08) => cyl(rad * (1 + (v % 3) * 0.04), rad, y, material, 0, y / 2, 0);
    const leaf = (x, y, z, sx, sy, sz, material = p, rx = 0, ry = 0, rz = 0) => {
      const m = sphere(0.48, material, x, y, z, sx, sy, sz); m.rotation.set(rx, ry, rz); return m;
    };
    const stem = (x, y, z, h, r = 0.08, material = w, lean = 0) => cyl(r * 0.78, r, h, material, x + lean * h / 2, y + h / 2, z, 0, 0, -lean);
    const branch = (x1, y1, z1, x2, y2, z2, r, material = p) => kit.tube([[x1,y1,z1],[(x1+x2)/2,(y1+y2)/2,(z1+z2)/2],[x2,y2,z2]],r,r*.56,material);
    const rosette = (x, y, z, count, radius, material = p, tilt = 0.38) => {
      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 * i) / count + v * 0.13;
        leaf(x + Math.cos(angle) * radius * 0.4, y + Math.sin(angle) * radius * 0.18, z + Math.sin(angle) * radius * 0.4, radius, radius * tilt, radius * 0.34, i % 3 ? material : s, 0, -angle, Math.cos(angle) * 0.25);
      }
    };

    switch (f) {
      case 'carvalho': {
        ground(1.12); stem(0,0,0,2.15*n,.3,w,.06);
        for(let i=0;i<5;i++){ const an=i*Math.PI*2/5; branch(0,1.3,0,Math.cos(an)*.92,2.35,Math.sin(an)*.92,.12,w); }
        const count=5+(v%4); for(let i=0;i<count;i++){let an=i*Math.PI*2/count; leaf(Math.cos(an)*.67,2.48+(i%2)*.22,Math.sin(an)*.67,1.52*n,1.16*n,1.46*n,i%3?p:s);}
        for(let i=0;i<4;i++){let an=i*Math.PI/2; branch(0,.26,0,Math.cos(an)*.82,.06,Math.sin(an)*.82,.16,w);} break;
      }
      case 'pinheiro':
        ground(.9); stem(0,0,0,3*n,.17,w);
        for(let i=0;i<4+(v%2);i++){const y=.82+i*.47; cone(1.05*n-i*.12,.98,p,0,y+.37,0);}
        break;
      case 'palmeira': {
        const h=2.8*n, lean=.24, crownX=h*(lean+Math.sin(lean))*.5, crownY=h*(1+Math.cos(lean))*.5;
        ground(.85); stem(0,0,0,h,.18,w,lean); sphere(.2,s,crownX,crownY,0,1,.7,1);
        const count=7+(v%4); for(let i=0;i<count;i++){
          const an=i*Math.PI*2/count, ex=crownX+Math.cos(an)*1.05, ez=Math.sin(an)*1.05, ey=crownY-.34;
          branch(crownX,crownY,0,ex,ey,ez,.065,p);
          leaf(crownX+Math.cos(an)*.67,crownY-.18,Math.sin(an)*.67,1.3,.16,.37,i%2?p:s,0,-an,.16);
        }
        for(let i=0;i<3;i++)sphere(.1,a,crownX+(i-1)*.12,crownY-.12,.09);
        break;
      }
      case 'baoba':
        ground(1.25); cyl(.56*n,.42,2*n, w,0,n,0); leaf(0,2.3*n,0,2.05*n,1.12*n,1.95*n,p);
        for(let i=0;i<5;i++){const an=i*Math.PI*2/5;leaf(Math.cos(an)*.74,2.16*n,Math.sin(an)*.74,.88*n,.66*n,.82*n,i%2?p:s);}
        for(let i=0;i<5;i++){const an=i*Math.PI*2/5; branch(0,.48,0,Math.cos(an)*.92,.07,Math.sin(an)*.92,.2,w);}
        for(let i=0;i<4;i++){const an=i*Math.PI/2; branch(0,1.35,0,Math.cos(an)*.86,2.38,Math.sin(an)*.86,.09,w);} break;
      case 'chorona':
        ground(1); stem(0,0,0,2.7*n,.22,w); leaf(0,2.72*n,0,1.15*n,.48*n,1.08*n,p);
        for(let i=0;i<9;i++){const an=i*Math.PI*2/9, x=Math.cos(an)*.85, z=Math.sin(an)*.85; branch(0,2.55,0,x,1.45+((i%3)*.12),z,.07,s); leaf(x,1.38,z,.2,.58,.2,i%2?p:s,0,-an,.25);} break;
      case 'mangue':
        ground(1.05,s,.12); stem(0,0,0,2.45*n,.2,w);
        for(let i=0;i<6+(v%3);i++){const an=i*Math.PI*2/(6+(v%3)),x=Math.cos(an)*.94,z=Math.sin(an)*.94; branch(0,1.9,x, x,.08,z,.11,w); stem(x,.08,z,.65,.055,w);}
        for(let i=0;i<5;i++) leaf(Math.cos(i*1.25)*.52,2.45,Math.sin(i*1.25)*.52,.57,.28,.52,p); break;
      case 'bambu':
        ground(1.05); for(let i=0;i<5+(v%4);i++){const an=i*2.4,rad=.45+(i%2)*.28,x=Math.cos(an)*rad,z=Math.sin(an)*rad,h=2.2+(i%3)*.42; stem(x,0,z,h,.09,w,(i%2?-.08:.08)); for(let j=1;j<5;j++) cyl(.094,.094,.035,a,x,h*j/5,z); for(let j=0;j<2;j++) leaf(x+(j?-.38:.38),h*.73,z+(j?.3:-.3),.4,.08,.14,p,0,an,.3); } break;
      case 'cacto':
        ground(.8); cyl(.3,.25,2.45*n,p,0,1.22*n,0);
        for(let side of [-1,1]){branch(0,1.03*n,0,side*.44,1.37*n,0,.15,p); sphere(.15,p,side*.44,1.37*n,0); cyl(.13,.13,.72,p,side*.44,1.73*n,0); sphere(.13,p,side*.44,2.1*n,0);}
        for(let i=0;i<10;i++){const an=i*2.4; leaf(Math.cos(an)*.27, .3+i*.19,Math.sin(an)*.27,.07,.05,.07,a);} break;
      case 'cogumelo': {
        ground(.72); stem(0,0,0,1.25*n,.2,l);
        const radius=.98*n, y=1.18*n;
        add(new kit.THREE.SphereGeometry(radius,24,12,0,Math.PI*2,0,Math.PI/2),p,0,y,0,0,0,0,1,.55,1);
        cyl(radius,radius,.035,l,0,y,0);
        for(let i=0;i<7+(v%3);i++){
          const an=i*6.283/(7+(v%3)), r=radius*.61, top=y+Math.sqrt(radius*radius-r*r)*.55;
          sphere(.065,l,Math.cos(an)*r,top,Math.sin(an)*r,1,.45,1);
        }
        for(let i=0;i<v%4;i++)sphere(.25,s,-.5+i*.33,.25,.44,.8,1,.8);
        break;
      }
      case 'flor':
        ground(.78); stem(0,0,0,1.45*n,.09,w); rosette(0,.36,0,5,.37,s,.32);
        for(let i=0;i<10+(v%5);i++){let an=i*6.283/(10+(v%5)); leaf(Math.cos(an)*.48,1.62*n,Math.sin(an)*.48,.55,.23,.36,a,0,-an,.12);}
        sphere(.34,p,0,1.68*n,0,1,.85,1); break;
      case 'samambaia':
        ground(.82); for(let i=0;i<7+(v%4);i++){let an=i*6.283/(7+(v%4)),x=Math.cos(an),z=Math.sin(an); branch(0,.15,0,x*.9,1.55+(i%3)*.1,z*.9,.055,w); for(let j=1;j<=3;j++){let t=j/4, y=.28+t*1.13;leaf(x*t*.92,y,z*t*.92,.22*(1-t*.42),.07,.12,p,0,-an,.34);leaf(-x*t*.92,y,-z*t*.92,.22*(1-t*.42),.07,.12,s,0,-an,-.34);}} break;
      case 'suculenta':
        ground(.92); sphere(.48,s,0,.28,0,1,.58,1); rosette(0,.62,0,9+(v%4),.92,p,.42); rosette(0,.88,0,6,.46,a,.55); leaf(0,1.15,0,.3,.48,.3,a); break;
      case 'lirio':
        cyl(1.4,1.45,.12,s,0,.06,0); for(let i=0;i<3+(v%3);i++){let an=i*6.283/(3+(v%3)); leaf(Math.cos(an)*.64,.2,Math.sin(an)*.64,.57,.09,.47,i%2?p:s,0,-an,.02);}
        stem(0,.13,0,.52,.04,w); rosette(0,.63,0,6,.25,a,.22); sphere(.15,l,0,.72,0); break;
      case 'coral':
        ground(.86,s,.15); for(let i=0;i<6+(v%4);i++){let an=i*6.283/(6+(v%4)),x=Math.cos(an)*.3,z=Math.sin(an)*.3,h=1.15+(i%3)*.28; branch(x,.12,z,x+Math.cos(an)*.38,h,z+Math.sin(an)*.38,.12+(i%2)*.02,i%3?a:p); for(let j=0;j<2;j++) branch(x+Math.cos(an)*.2,.55,z+Math.sin(an)*.2,x+Math.cos(an+j*.8)*.65,h*.82,z+Math.sin(an+j*.8)*.65,.07,a); } break;
      case 'recife':
        ground(1.12,s,.18); for(let i=0;i<5+(v%4);i++){let an=i*2.4,rad=.55+(i%2)*.2; sphere(.48+(i%3)*.1,i%2?p:a,Math.cos(an)*rad,.4,Math.sin(an)*rad,1,.72,1); for(let j=0;j<3;j++) torus(.2+j*.09,.025,d,Math.cos(an)*rad,.43+j*.1,Math.sin(an)*rad,Math.PI/2,0,0); } break;
      case 'alga':
        ground(.9,s,.1); for(let i=0;i<7+(v%4);i++){let an=i*6.283/(7+(v%4)),x=Math.cos(an)*.57,z=Math.sin(an)*.57,h=1.9+(i%3)*.38; branch(x,0,z,x+Math.sin(an)*.18,h,z+Math.cos(an)*.2,.06,s); for(let j=1;j<=4;j++)leaf(x+Math.sin(an)*.1,j*h/5,z+Math.cos(an)*.12,.22,.36,.11,j%2?p:a,0,-an,.38);} break;
      case 'rochas':
        ground(1.12,d,.12); for(let i=0;i<7+(v%4);i++){let an=i*2.4,rad=.55+(i%3)*.2,h=.65+(i*7%5)*.24; const m=add(new kit.THREE.DodecahedronGeometry(.56,0),i%3?p:s,Math.cos(an)*rad,h/2,Math.sin(an)*rad,0,an*.6,.15,1,h,1); } break;
      case 'arco':
        ground(1.25,d,.12); box(.42,2.05*n,.48,s,-.83,1,0,0,0,-.08); box(.42,2.05*n,.48,p,.83,1,0,0,0,.08); box(2.05,.48,.52,s,0,2.04*n,0,0,0,.03);
        for(let i=0;i<4;i++){let x=-.8+i*.53; sphere(.31,i%2?p:d,x,2.18*n,0,1,.75,1);} break;
      case 'cristais':
        ground(.95,d,.12); for(let i=0;i<7+(v%4);i++){let an=i*2.4,rad=(i%3)*.24,h=.7+(i*7%6)*.24; cone(.35+(i%2)*.08,h,i%3?a:p,Math.cos(an)*rad,h/2+.1,Math.sin(an)*rad,0,an,.08); cone(.29,h*.72,l,Math.cos(an)*rad,h*.86+.1,Math.sin(an)*rad,0,an,.08);} break;
      case 'vulcao':
        ground(1.25,d,.15); add(new kit.THREE.CylinderGeometry(.62,1.22,1.58*n,12,1,true),s,0,.79*n,0); torus(.62,.13,d,0,1.58*n,0,Math.PI/2,0,0); cyl(.48,.54,.1,a,0,1.48*n,0);
        for(let i=0;i<4;i++){let an=i*1.57; branch(Math.cos(an)*.7,.8,Math.sin(an)*.7,Math.cos(an)*.84,.28,Math.sin(an)*.84,.1,d);} 
        for(let i=0;i<3;i++) sphere(.13,a,(i-1)*.28,1.82*n,.05,.8,.65,.8); break;
      case 'geyser':
        ground(1.08,d,.13); for(let i=0;i<8;i++){let an=i*6.283/8; sphere(.38,i%2?s:d,Math.cos(an)*.68,.26,Math.sin(an)*.68,1,.7,1);}
        cyl(.32,.52,.2,a,0,.42,0); cyl(.14,.25,1.5*n,l,0,1.24*n,0); sphere(.22,l,0,2.05*n,0,1.5,.8,1); for(let i=0;i<3;i++) sphere(.12,l,(i-1)*.34,1.7*n,.12); break;
      case 'ilha':
        cone(1.2,1.45*n,d,0,-.68*n,0); cyl(1.3,1.1,.22,s,0,.05,0); sphere(1,p,0,.2,0,1.1,.25,1);
        stem(-.34,.18,0,1.15,.1,w,.16); leaf(-.13,1.4,0,.56,.32,.5,p); for(let i=0;i<3;i++) sphere(.22,a,.45+i*.27,.28,.2,.8,.6,.8);
        for(let i=0;i<4;i++){let an=i*1.57; leaf(Math.cos(an)*.95,.16,Math.sin(an)*.95,.32,.1,.22,i%2?s:p);} break;
      case 'cascata':
        ground(1.2,d,.15); box(2.05,.62,.62,s,0,1.64,0); box(1.65,.42,.58,d,0,1.13,-.03); box(1.12,.34,.55,s,0,.72,0);
        { const flowW=.4+v*.075, flowH=.92+v*.055; box(flowW,flowH,.18,l,.12,.25+flowH/2,.34,0,0,-.04-v*.009);
        const tiers=2+Math.floor(v/3); for(let i=0;i<tiers;i++){const yy=.18+i*.2, xx=-.62+i*(1.24/Math.max(1,tiers-1)); box(.38,.09,.55,i%2?s:d,xx,yy,-.08);}
        box(.9,.13,.6,a,0,.13,.04); }
        for(let i=0;i<4;i++) sphere(.25,p,-.72+i*.47,.3,-.35,1,.6,1); break;
      case 'raizes':
        { const spread=.62+v*.09, crown=1.82+v*.065, bend=.14+v*.022;
        ground(1,d,.13); for(let i=0;i<4;i++){let x=-spread+i*(spread*2/3), side=i%2?1:-1; branch(x,.12,-.18,x+side*bend,1.05+v*.018,.12,.17+(i%2)*.02,w); branch(x+side*bend,1.05+v*.018,.12,x+side*(.3+v*.025),crown,-.12,.15,w);}
        box(spread*1.85,.28,.42,w,0,crown-.1,0); for(let i=0;i<3;i++) leaf(-spread*.62+i*spread*.62,crown+.2,.04,.42+v*.012,.2,.4,p); } break;
      case 'bonsai':
        { const lean=-.12-v*.032, canopyW=.42+v*.035, canopyY=1.55+v*.045;
        ground(.85,d,.14); add(new kit.THREE.DodecahedronGeometry(.7+v*.018,0),s,0,.36,0,.1,.4,.1,1,.65,1); stem(.05,.52,0,1.2+v*.035,.13,w,lean);
        branch(.02,1.25,0,-.48-v*.018,1.58+v*.04,.06,.08,w); branch(-.2,1.45,0,.48+v*.025,1.66+v*.045,-.12,.07,w);
        for(let i=0;i<4;i++)leaf(-canopyW+(i%2)*canopyW*2,canopyY+Math.floor(i/2)*(.18+v*.008),(i%2?-.12:.08),.96+v*.03,.58,.88+v*.025,i%2?p:s); } break;
    }

    // Give every biome a distinct silhouette profile. Apply it to each mesh added
    // by this build so the profile changes the full form, not just its ground disc.
    const width = .84 + v * .035;
    const height = 1.16 - v * .035;
    for (let i = firstNewChild; i < kit.root.children.length; i++) {
      const child = kit.root.children[i];
      if (child.position) { child.position.x *= width; child.position.z *= width; child.position.y *= height; }
      if (child.scale) { child.scale.x *= width; child.scale.z *= width; child.scale.y *= height; }
    }
  }
  return { assets, build };
}
