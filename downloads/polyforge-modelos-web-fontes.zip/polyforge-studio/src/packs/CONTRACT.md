# Expansion pack contract

## Counting and quality correction

A generated biome configuration is a variant, not a new unique model. Count one family card per pack/form. Vertex hashes, nonuniform scales, footings, grip rings, colors and tiny adornments are mechanical differences, not proof of visual originality. The original request for 1,000 visually distinct new models remains unmet. Never use the 1,000 internal variant configurations as a claim of 1,000 new models.

Each pack is one plain JS file containing one top-level named function `createNaturePack(biomes)`, `createAnimalsPack(biomes)`, `createObjectsPack(biomes)`, or `createCharactersPack(biomes)`.
Return `{ assets, build(asset, kit) }`. Exactly 250 assets per pack: 25 structurally different forms × 10 biomes. No external imports, DOM, network, random Math.random or edits to index.html. Self-contained builders are included in exported HTML/code.

`biomes`: 10 objects `{id,name,adjective,colors:{primary,secondary,accent},index}` with ids forest, desert, tundra, swamp, savanna, ocean, volcanic, crystal, jungle, sky. Labels in Portuguese. Each asset: `{id,name,category,categoryLabel,icon,description,defaultColors:{primary,secondary,accent},roughness,metalness,emissive,biome,form,variant,seed,pack}`. `variant` biome index 0..9; `seed` positive deterministic integer. IDs unique with pack prefix: nature `natx_`, animals `petx_`, objects `objx_`, characters `charx_`. categories nature/pets/(items or props)/characters respectively. `pack` nature/animals/objects/characters. `equipSlot` optional 'right'|'left'|'head'|'shield' for equipment. 250 distinct names. Variant changes geometry (size, number, appendages, decoration, silhouette), not only colors. Descriptions accurate.

`kit`: `{ THREE, root, mat, rng, group, add, sphere, box, cylinder, cone, torus, tube }`.
- mat: primary,secondary,accent,dark,light,wood,skin. Three Materials. Can clone and customize.
- `rng()` seeded [0,1).
- `group(part='',x=0,y=0,z=0,parent=root)` returns Group, sets userData.part if given. Use for animation pivots.
- `add(geo,mat,x=0,y=0,z=0,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1,parent=root)` returns mesh.
- `sphere(r,mat,x,y,z,sx=1,sy=1,sz=1,parent=root)` returns mesh.
- `box(w,h,d,mat,x,y,z,rx=0,ry=0,rz=0,parent=root)` rounded box returns mesh.
- `cylinder(rt,rb,h,mat,x,y,z,rx=0,ry=0,rz=0,parent=root)`.
- `cone(r,h,mat,x,y,z,rx=0,ry=0,rz=0,parent=root)`.
- `torus(r,tube,mat,x,y,z,rx=0,ry=0,rz=0,parent=root)`.
- `tube(pointsArray3D,rStart,rEnd,mat,parent=root)` tapered curved tube, closed caps.
All positions finite. Positive radii/dimensions. Use <=50 meshes typical, <=90 maximum. Character groups part labels torso/head/leftArm/rightArm/leftForearm/rightForearm/leftLeg/rightLeg/leftShin/rightShin/cape/tail/leftWing/rightWing/spinPart/floating. head/arms under torso where reasonable. Default at origin facing +Z. Root grounded and scaled by orchestrator after pack build. Don't ground or set root scale yourself. Equipment remains grip-relative at origin when config.isEquipped, so build handles/pivots at origin for items. Characters provide named WeaponSocket, LeftWeaponSocket, ShieldSocket, HeadSocket with useful attachment transforms; use root.userData.combatType = melee/magic/gun/bow and honor `kit.config.hideDefaultWeapon/hideDefaultShield`. Every character should have weapon/grip at most one, sane face and distinctive profession.
`build` adds meshes under kit.root. No return needed. Kit will set rest pose metadata afterward.

Store form list metadata outside build inside factory closure if desired. Build may use closure form arrays/biomes because factory is exported intact. Use deterministic parameters from asset.form and asset.variant.
