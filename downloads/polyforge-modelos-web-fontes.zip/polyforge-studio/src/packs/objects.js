function createObjectsPack(biomes) {
  const forms = [
    { name: 'Espada de guarda', icon: '🗡️', category: 'items', slot: 'right', combat: 'melee', desc: 'espada de uma mão' },
    { name: 'Martelo de guerra', icon: '🔨', category: 'items', slot: 'right', combat: 'melee', desc: 'martelo de combate' },
    { name: 'Machado de batalha', icon: '🪓', category: 'items', slot: 'right', combat: 'melee', desc: 'machado de batalha' },
    { name: 'Lança de caça', icon: '🔱', category: 'items', slot: 'right', combat: 'melee', desc: 'lança de caça' },
    { name: 'Cajado rúnico', icon: '🪄', category: 'items', slot: 'right', combat: 'magic', desc: 'cajado arcano' },
    { name: 'Adaga curva', icon: '🗡', category: 'items', slot: 'right', combat: 'melee', desc: 'adaga curva' },
    { name: 'Besta de mão', icon: '🏹', category: 'items', slot: 'right', combat: 'gun', desc: 'besta mecânica de mão' },
    { name: 'Pistola de pederneira', icon: '🔫', category: 'items', slot: 'right', combat: 'gun', desc: 'pistola de pederneira' },
    { name: 'Escudo torre', icon: '🛡️', category: 'items', slot: 'shield', desc: 'escudo de defesa' },
    { name: 'Elmo de crista', icon: '⛑️', category: 'items', slot: 'head', desc: 'elmo de proteção' },
    { name: 'Barril de provisões', icon: '🛢️', category: 'props', desc: 'barril reforçado' },
    { name: 'Baú de viagem', icon: '🧰', category: 'props', desc: 'baú de viagem' },
    { name: 'Banco de praça', icon: '🪑', category: 'props', desc: 'banco de madeira' },
    { name: 'Mesa de mapas', icon: '🗺️', category: 'props', desc: 'mesa de exploração' },
    { name: 'Lampião de poste', icon: '🏮', category: 'props', desc: 'lampião de rua' },
    { name: 'Poço de pedra', icon: '🪨', category: 'props', desc: 'poço circular' },
    { name: 'Torre de vigia', icon: '🗼', category: 'props', desc: 'torre de observação' },
    { name: 'Cabana de campo', icon: '🏠', category: 'props', desc: 'cabana de campo' },
    { name: 'Moinho de vento', icon: '🌬️', category: 'props', desc: 'moinho com pás' },
    { name: 'Bigorna de ferreiro', icon: '⚒️', category: 'props', desc: 'bigorna de oficina' },
    { name: 'Forno de fundição', icon: '🔥', category: 'props', desc: 'forno de fundição' },
    { name: 'Carroça de carga', icon: '🛒', category: 'props', desc: 'carroça de exploração' },
    { name: 'Totem guardião', icon: '🗿', category: 'props', desc: 'totem entalhado' },
    { name: 'Ponte de trilha', icon: '🌉', category: 'props', desc: 'ponte de travessia' },
    { name: 'Bancada de alquimia', icon: '⚗️', category: 'props', desc: 'bancada de oficina' }
  ];
  const assets = [];
  for (let fi = 0; fi < forms.length; fi++) for (let bi = 0; bi < biomes.length; bi++) {
    const f = forms[fi], b = biomes[bi];
    assets.push({ id: `objx_${String(fi + 1).padStart(2, '0')}_${String(bi + 1).padStart(2, '0')}`, name: `${f.name} — ${b.name}`, category: f.category, categoryLabel: f.category === 'items' ? 'Equipamento' : 'Objeto', icon: f.icon, description: `${f.desc} em estilo ${b.adjective}, com estrutura e ornamentos próprios deste bioma.`, defaultColors: { ...b.colors }, roughness: f.category === 'items' ? 0.38 : 0.76, metalness: f.category === 'items' ? 0.48 : 0.12, emissive: 0, biome: b.id, form: f.name, variant: bi, seed: 7301 + fi * 97 + bi * 31, pack: 'objects', ...(f.slot ? { equipSlot: f.slot } : {}) });
  }

  function build(asset, kit) {
    const { mat, box, sphere, cylinder, cone, torus, group } = kit;
    const f = forms.find(x => x.name === asset.form), i = forms.indexOf(f), v = asset.variant;
    const p = mat.primary, s = mat.secondary, a = mat.accent, w = mat.wood, d = mat.dark, l = mat.light;
    const tall = 1 + (v % 4) * 0.075, wide = 1 + ((v + 1) % 3) * 0.09;
    if (f.combat) kit.root.userData.combatType = f.combat;
    switch (i) {
      case 0: // blade with guard and pommel, grip at ground origin
        cylinder(.055,.07,.42,w,0,.21,0,0,0); torus(.07,.018,a,0,.45,0,0,0,0); box(.34,.07,.11,a,0,.51,0); box(.11,.68,.055,s,0,.88,0); cone(.095,.24,l,0,1.34,0); sphere(.095,a,0,.47,0); break;
      case 1: cylinder(.065,.075,.43,w,0,.215); cylinder(.045,.05,.4,s,0,.65); box(.43*wide,.27,.2,p,0,.91,0); sphere(.14,s,-.25,.91,0,1,1,1.2); sphere(.14,s,.25,.91,0,1,1,1.2); box(.2,.09,.24,a,0,.91,0); break;
      case 2: cylinder(.065,.075,.42,w,0,.21); cylinder(.04,.055,.42,s,0,.63); box(.42*wide,.38,.12,p, -.18,.91,0,0,0,-.25); cone(.19,.28,s,-.31,1.12,0,0,0,Math.PI/2); box(.12,.14,.18,a,-.12,.91,0); break;
      case 3: cylinder(.055,.06,.43,w,0,.215); cylinder(.035,.05,.42,s,0,.64); cone(.105,.28,l,0,1.04,0); box(.27,.08,.13,a,0,.9,0); sphere(.08,p,.15,.86,0); break;
      case 4: cylinder(.065,.075,1.18,w,0,.59); torus(.095,.025,a,0,1.28,0,0,0,0); sphere(.18,p,0,1.48,0,1,1,1); for(let j=0;j<3+(v%3);j++){let ang=j*Math.PI*2/(3+v%3); sphere(.045,a,Math.cos(ang)*.19,1.48+Math.sin(ang)*.14,0); } cylinder(.1,.1,.13,s,0,.2); break;
      case 5: cylinder(.05,.06,.37,w,0,.185); box(.1,.42,.08,s,0,.58,0,0,0,-.42); cone(.075,.35,l,.08,.91,0,0,0,Math.PI/2); sphere(.08,a,0,.43,0); break;
      case 6: box(.48,.12,.18,w,0,.18,0); box(.13,.54,.11,s,0,.52,0); box(.58,.09,.1,a,0,.54,0); box(.1,.28,.1,s,-.23,.72,0,0,0,.3); box(.1,.28,.1,s,.23,.72,0,0,0,-.3); sphere(.08,a,0,.82,0); break;
      case 7: box(.2,.52,.14,w,0,.31); cylinder(.045,.06,.33,s,0,.735,0,Math.PI/2,0); torus(.11,.022,a,0,.34,.09); box(.1,.28,.12,w,0,.66); cylinder(.02,.02,.25,d,0,.84,0,Math.PI/2,0); break;
      case 8: // Shield plate, inset panel, and rim vary in both width and height.
        box(.62*wide,.9*tall,.14,s,0,.48,0); box(.42*wide,.67*tall,.08,p,0,.49,-.09); torus(.12*wide,.025,a,0,.49,.005); box(.72*wide,.1,.19,a,0,.48,0); sphere(.09,a,0,.48,.08); for(let j=0;j<v+1;j++){let side=j%2===0?-1:1, row=Math.floor(j/2);sphere(.032+.0015*v,s,side*(.245+.006*v),.16+row*.12,.095); } break;
      case 9: { // Open-bottom helm with climate-specific crown profile and cheek guards.
        const crownHeight=.28*tall;
        cylinder(.32*wide,.35*wide,crownHeight,p,0,.22); sphere(.32*wide,p,0,.28+crownHeight*.6,0,1,.58*tall,1); torus(.34*wide,.035,s,0,.22+crownHeight*.48,0); box(.6*wide,.09+.008*v,.14,a,0,.34,.25); box(.12*wide,.25+.018*v,.1,s,-.25*wide,.18,.02,0,0,-.12); box(.12*wide,.25+.018*v,.1,s,.25*wide,.18,.02,0,0,.12); cone(.085*wide,.18+.018*v,s,0,.59+.012*v,0); sphere(.07,a,0,.35,.28);
        // A row of rivets and side guards adds a clear, biome-indexed profile to every helm.
        for(let j=0;j<v+1;j++){const side=j%2===0?-1:1,row=Math.floor(j/2);sphere(.026+.001*v,a,side*(.285*wide),.16+row*.035,.04);}
        break;
      }
      case 10: cylinder(.42*wide,.4*wide,.78*tall,w,0,.39,0,0,0); torus(.41,.035,s,0,.12,0); torus(.41,.035,s,0,.66,0); for(let j=0;j<3+(v%3);j++){let z=(j-1)*.18; box(.035,.7*tall,.72,w,(j-1)*.2,.39,0,0,0,0); } box(.08,.8,.06,a,0,.39,.39); break;
      case 11: box(.82,.56,.55,w,0,.31); box(.9,.12,.62,s,0,.64); box(.12,.22,.08,a,0,.48,.33); box(.12,.22,.08,a,0,.48,-.33); box(.08,.12,.08,a,0,.64,.34); break;
      case 12: box(1,.1,.24,w,0,.58); for(let x of [-.38,-.13,.13,.38]) box(.08,.28,.11,w,x,.4,0); box(1,.08,.19,w,0,.25,0); for(let x of [-.43,.43]) box(.08,.38,.11,w,x,.31,0,0,0,x*.25); break;
      case 13: box(.95,.12,.7,w,0,.72); for(let x of [-.38,.38]) for(let z of [-.25,.25]) box(.09,.68,.09,w,x,.34,z); box(.3,.025,.23,s,0,.8,.06); cylinder(.045,.045,.28,a,0,.88,.25); break;
      case 14: cylinder(.07,.1,1.55*tall,w,0,.77); box(.28,.08,.26,a,0,1.48,0); torus(.17,.035,a,0,1.56,0,Math.PI/2,0,0); sphere(.14,l,0,1.56,.02); cone(.22,.2,s,0,1.72,0); break;
      case 15: cylinder(.56,.6,.18,s,0,.09); for(let j=0;j<8+(v%4);j++){let an=j*Math.PI*2/(8+v%4); box(.16,.34,.16,s,Math.cos(an)*.51,.31,Math.sin(an)*.51,0,-an,0); } torus(.53,.045,a,0,.47,0); cylinder(.34,.34,.1,d,0,.48); break;
      case 16: cylinder(.47,.63,1.5*tall,s,0,.75); cylinder(.55,.58,.14,w,0,.12); cylinder(.53,.53,.13,w,0,1.44*tall); box(.88,.12,.62,w,0,1.54*tall,0); for(let j=0;j<4+(v%3);j++) box(.055,.5,.065,a,(j-1.5)*.2,.8,.33); break;
      case 17: box(.95,.72,.78,w,0,.38); cone(.75*wide,.62,s,0,1.05,0); box(.3,.46,.09,d,0,.24,.405); box(.13,.1,.08,a,.17,.16,.46); box(.15,.1,.13,w,0,1.25,.2); break;
      case 18: cylinder(.34,.42,.8,w,0,.4); cylinder(.04,.04,.55,s,0,.91); box(.08,1.04,.08,w,0,1.36,0); { const rotor = group('spinZ',0,1.36,.43); for(let j=0;j<4;j++){let an=j*Math.PI/2+v*.13; box(.13,.68,.08,s,-Math.sin(an)*.44,Math.cos(an)*.44,0,0,0,an,rotor); } sphere(.12,a,0,0,.055,1,1,1,rotor); } torus(.43,.035,a,0,.83,0); break;
      case 19: cylinder(.43,.48,.22,s,0,.11); box(.78,.18,.25,s,0,.31,0); box(.32,.19,.33,s,.2,.49,0); sphere(.07,a,-.22,.43,0); break;
      case 20: cylinder(.37,.47,.7,s,0,.35); sphere(.38,p,0,.73,0,1,.8,1); cylinder(.45,.47,.13,s,0,.15); box(.42,.3,.38,d,0,.49,.25); torus(.13,.035,a,0,.54,.45,Math.PI/2); cone(.12,.19,s,0,.94,0); break;
      case 21: box(1,.16,.68,w,0,.46,0); box(.14,.34,.48,w,0,.68,-.05); box(.15,.36,.48,w,0,.68,.32); for(let z of [-.35,.35]){torus(.27,.045,s,0,.28,z); cylinder(.04,.04,.5,s,0,.28,z,Math.PI/2); } box(.09,.62,.1,w,0,.72,-.48); break;
      case 22: cylinder(.32,.38,1.18,s,0,.59); for(let j=0;j<3+(v%3);j++){let y=.28+j*.31; box(.54,.2,.46,p,0,y,.03); sphere(.12,a,0,y,.28,1,1,1); } cone(.42,.32,a,0,1.27,0); box(.72,.12,.16,w,0,.34,0); break;
      case 23: for(let j=0;j<5+(v%3);j++) box(.24,.18,.95,w,(j-(4+v%3)/2)*.23,.09,0); for(let z of [-.42,.42]) cylinder(.035,.035,1.35,s,0,.17,z,Math.PI/2); box(.12,.42,.1,w,-.56,.2,0); box(.12,.42,.1,w,.56,.2,0); break;
      case 24: box(.9,.12,.58,w,0,.61,0); for(let x of [-.36,.36]) box(.09,.58,.09,w,x,.3,0); cylinder(.19,.19,.18,s,0,.77,0); sphere(.12,a,0,.93,0); for(let x of [-.25,.25]) cylinder(.07,.07,.28,a,x,.8,.14); box(.16,.31,.1,s,0,.84,-.18); break;
    }
    // Each climate alters the silhouette through varied proportions and a small, readable structural accent.
    if (i >= 10) {
      if (v % 3 === 0) { sphere(.09,a,-.34,.16,.04); sphere(.07,a,.34,.16,-.04); }
      else if (v % 3 === 1) { cone(.12,.24,s,-.34,.22,.12); cone(.12,.24,s,.34,.22,-.12); }
      else { torus(.12,.025,a,0,.18,.2,Math.PI/2,0,0); }
      // A shallow, differently sized footing changes each prop's footprint and gives structures a grounded base.
      box(.92+.018*v,.035,.66+.014*v,s,0,.018,0);
    } else if (i !== 8 && i !== 9) {
      if (v % 2 === 0) sphere(.055,a,.11,1.1,.07);
      else torus(.07,.018,a,0,.68,.03,Math.PI/2,0,0);
      // Repeated grip bands vary in count and spacing while keeping weapon handles at the origin.
      if (i < 8) for(let j=0;j<v+1;j++) torus(.052+.0015*v,.008,a,0,.075+j*.027,0,Math.PI/2,0,0);
    }
  }
  return { assets, build };
}
