function expansionBiomes() {
    return [
        ['forest','Floresta','da Floresta','#4e9273','#714f3a','#d8c77a'],
        ['desert','Deserto','do Deserto','#d2aa70','#805347','#53b7b4'],
        ['tundra','Tundra','da Tundra','#ccdce5','#5b7284','#8dcacb'],
        ['swamp','Pântano','do Pântano','#6e8970','#4f474d','#b6ce70'],
        ['savanna','Savana','da Savana','#c5a36c','#795338','#e4cc82'],
        ['ocean','Oceano','do Oceano','#58a5ae','#435f8b','#ecb79a'],
        ['volcanic','Vulcão','Vulcânico','#725d65','#34394b','#ed9b69'],
        ['crystal','Cristal','de Cristal','#a99ccf','#5d628c','#9be1db'],
        ['jungle','Selva','da Selva','#4a967b','#55694b','#e5ad82'],
        ['sky','Céus','dos Céus','#d1dce5','#7b8dab','#e5ca86']
    ].map((b,index)=>({id:b[0],name:b[1],adjective:b[2],colors:{primary:b[3],secondary:b[4],accent:b[5]},index}));
}

function createAssetKit(THREE, config, seed) {
    const root = new THREE.Group();
    let randomState = seed >>> 0;
    const rng = () => { randomState = (Math.imul(randomState,1664525)+1013904223)>>>0; return randomState/4294967296; };
    const material = (color,roughness=0.65,metalness=0.03,emissive=0) => {
        const m=new THREE.MeshStandardMaterial({color,roughness,metalness,flatShading:!!config.flatShading});
        m.color.convertSRGBToLinear();
        if(emissive){m.emissive.copy(m.color);m.emissiveIntensity=emissive;}
        return m;
    };
    const rough = config.roughness ?? 0.65, metal = config.metalness ?? 0.04;
    const mat={primary:material(config.primaryColor||'#648e7a',rough,metal),secondary:material(config.secondaryColor||'#596377',Math.min(1,rough+.08),metal*.7),accent:material(config.accentColor||'#e5bd83',.48,.12,(config.emissive||0)*.3),dark:material('#273145',.76),light:material('#e9e4d9',.7),wood:material('#81604b',.86),skin:material('#d4a585',.78)};
    function group(part='',x=0,y=0,z=0,parent=root){const g=new THREE.Group();g.position.set(x,y,z);if(part){g.userData.part=part;g.name=part;}parent.add(g);return g;}
    function add(geo,material,x=0,y=0,z=0,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1,parent=root){const mesh=new THREE.Mesh(geo,material);mesh.position.set(x,y,z);mesh.rotation.set(rx,ry,rz);mesh.scale.set(sx,sy,sz);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;}
    function sphere(r,m,x=0,y=0,z=0,sx=1,sy=1,sz=1,parent=root){return add(new THREE.SphereGeometry(r,16,12),m,x,y,z,0,0,0,sx,sy,sz,parent);}
    function box(w,h,d,m,x=0,y=0,z=0,rx=0,ry=0,rz=0,parent=root){
        const radius=Math.min(w,h,d)*.17;
        const geo=new THREE.BoxGeometry(w,h,d,4,4,4),pos=geo.attributes.position,norm=geo.attributes.normal;
        const inner=new THREE.Vector3(w/2-radius,h/2-radius,d/2-radius),v=new THREE.Vector3(),c=new THREE.Vector3(),n=new THREE.Vector3();
        for(let i=0;i<pos.count;i++){v.fromBufferAttribute(pos,i);c.set(Math.max(-inner.x,Math.min(inner.x,v.x)),Math.max(-inner.y,Math.min(inner.y,v.y)),Math.max(-inner.z,Math.min(inner.z,v.z)));n.copy(v).sub(c).normalize();v.copy(c).addScaledVector(n,radius);pos.setXYZ(i,v.x,v.y,v.z);norm.setXYZ(i,n.x,n.y,n.z);}
        return add(geo,m,x,y,z,rx,ry,rz,1,1,1,parent);
    }
    function cylinder(rt,rb,h,m,x=0,y=0,z=0,rx=0,ry=0,rz=0,parent=root){return add(new THREE.CylinderGeometry(rt,rb,h,16),m,x,y,z,rx,ry,rz,1,1,1,parent);}
    function cone(r,h,m,x=0,y=0,z=0,rx=0,ry=0,rz=0,parent=root){return add(new THREE.ConeGeometry(r,h,16),m,x,y,z,rx,ry,rz,1,1,1,parent);}
    function torus(r,t,m,x=0,y=0,z=0,rx=0,ry=0,rz=0,parent=root){return add(new THREE.TorusGeometry(r,t,8,24),m,x,y,z,rx,ry,rz,1,1,1,parent);}
    function tube(points,rStart,rEnd,m,parent=root){
        const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));
        const segments=16,sides=8,frames=curve.computeFrenetFrames(segments,false),positions=[],indices=[];
        for(let i=0;i<=segments;i++){const t=i/segments,p=curve.getPointAt(t),r=Math.max(.001,rStart*(1-t)+rEnd*t);for(let j=0;j<=sides;j++){const a=j/sides*Math.PI*2;const offset=new THREE.Vector3().addScaledVector(frames.normals[i],Math.cos(a)*r).addScaledVector(frames.binormals[i],Math.sin(a)*r);positions.push(p.x+offset.x,p.y+offset.y,p.z+offset.z);}}
        for(let i=0;i<segments;i++)for(let j=0;j<sides;j++){const a=i*(sides+1)+j,b=a+sides+1;indices.push(a,a+1,b,b,a+1,b+1);}
        const bottom=positions.length/3,first=curve.getPointAt(0);positions.push(first.x,first.y,first.z);
        const top=positions.length/3,last=curve.getPointAt(1);positions.push(last.x,last.y,last.z);
        for(let j=0;j<sides;j++){indices.push(bottom,j+1,j);const a=segments*(sides+1)+j;indices.push(top,a,a+1);}
        const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setIndex(indices);geo.computeVertexNormals();return add(geo,m,0,0,0,0,0,0,1,1,1,parent);
    }
    return {THREE,root,config,mat,rng,group,add,sphere,box,cylinder,cone,torus,tube};
}

function buildExpansionModel(modelId,config={}) {
    const entry=EXPANSION_ASSET_INDEX.get(modelId);
    if(!entry) throw new Error('Asset desconhecido: '+modelId);
    const {asset,pack}=entry;
    const cfg=Object.assign({primaryColor:asset.defaultColors.primary,secondaryColor:asset.defaultColors.secondary,accentColor:asset.defaultColors.accent,roughness:asset.roughness,metalness:asset.metalness,emissive:asset.emissive},config);
    const kit=createAssetKit(THREE,cfg,asset.seed);pack.build(asset,kit);
    const group=kit.root;group.name='Model_'+asset.id;
    group.userData.assetId=asset.id;group.userData.biome=asset.biome;group.userData.pack=asset.pack;
    if(!cfg.isEquipped){group.scale.set(cfg.scaleX||1,cfg.scaleY||1,cfg.scaleZ||1);group.updateMatrixWorld(true);const box=new THREE.Box3().setFromObject(group);if(!box.isEmpty()){const lift=-box.min.y/group.scale.y;group.children.forEach(child=>child.position.y+=lift);}}
    group.traverse(child=>{if(child!==group){child.userData.basePos=child.position.clone();child.userData.baseRot=child.rotation.clone();child.userData.baseScale=child.scale.clone();}});
    return group;
}

function equipItemToModel(hero,itemData,config={}) {
    if(!hero||!itemData)return null;
    const slot=itemData.equipSlot||(itemData.id.startsWith('item_shield_')?'shield':itemData.id==='item_crown'?'head':itemData.id==='item_bow'?'left':'right');
    const socket=hero.getObjectByName({shield:'ShieldSocket',head:'HeadSocket',left:'LeftWeaponSocket',right:'WeaponSocket'}[slot]);
    if(!socket)return null;
    const item=buildProceduralModel(itemData.id,{primaryColor:itemData.defaultColors.primary,secondaryColor:itemData.defaultColors.secondary,accentColor:itemData.defaultColors.accent,roughness:itemData.roughness,metalness:itemData.metalness,emissive:itemData.emissive,flatShading:!!config.flatShading,isEquipped:true});
    if(slot==='head')item.scale.setScalar(.46);
    else if(slot==='shield'){item.rotation.y=-Math.PI/2;item.scale.setScalar(.55);}
    else if(slot==='left')item.scale.setScalar(.85);
    else if(item.userData.combatType==='gun')item.scale.setScalar(.55);
    else {item.rotation.x=Math.PI/2.2;item.scale.setScalar(.58);}
    socket.add(item);if(item.userData.combatType)hero.userData.effectiveCombatType=item.userData.combatType;
    return item;
}

function getExpansionSource(){
    return [expansionBiomes,createAssetKit,createNaturePack,createAnimalsPack,createObjectsPack,createCharactersPack,buildExpansionModel,equipItemToModel].map(fn=>fn.toString()).join('\n\n')+'\n'+
    "const EXPANSION_BIOMES=expansionBiomes();\nconst EXPANSION_PACKS=[createNaturePack(EXPANSION_BIOMES),createAnimalsPack(EXPANSION_BIOMES),createObjectsPack(EXPANSION_BIOMES),createCharactersPack(EXPANSION_BIOMES)];\nconst EXPANSION_ASSET_INDEX=new Map(EXPANSION_PACKS.flatMap(pack=>pack.assets.map(asset=>[asset.id,{asset,pack}])));\n";
}
