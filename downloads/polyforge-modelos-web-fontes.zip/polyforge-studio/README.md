# PolyForge Studio — modelos de autores

A biblioteca visível usa **35 arquivos GLB baixados**, de Quaternius e Kenney, com licença **CC0 1.0**. Os modelos procedurais anteriores foram retirados do catálogo principal. A base de exposição, iluminação e composição do cenário são recursos do estúdio.

Esta seleção contém três personagens, dez animais, doze modelos de natureza, nove objetos e uma canoa na categoria de veículos. Há cinco arquivos alternativos preservados nos fontes, fora da biblioteca: dois designs próximos de objetos e três personagens com estética diferente da seleção. Não há contagem de mil modelos ou de biomas como modelos adicionais.

## Abrir

O `index.html` é portátil: bibliotecas, miniaturas e GLBs estão incorporados. Abra-o num navegador atual com WebGL e suporte a `DecompressionStream` (Chrome, Edge, Firefox ou Safari atuais). A primeira abertura carrega os arquivos incluídos e exibe o progresso. Não precisa acessar CDNs, Poly Pizza ou Kenney em execução.

Também é possível servir a pasta com `python -m http.server 8000`.

## Recursos

- Busca e filtros por categoria e autor, com miniaturas renderizadas dos próprios arquivos.
- Materiais, texturas, malhas e esqueletos do GLB original. O seletor do inspetor permite alterar cada material e restaurar o arquivo.
- Animações originais onde existem. Clipes duplicados por prefixo de armadura são agrupados na lista; controles sem clipe correspondente ficam desativados.
- Enquadramento automático, modo de escultura, captura PNG, OBJ estático da pose e download do **GLB original**.
- Personagem com animal companheiro, movimento de teste, pulo e exportação de uma cena jogável em HTML.
- Composições de cenário usam cópias dos arquivos baixados. Essas cópias não acrescentam modelos à contagem da biblioteca.
- Fonte e licença acessíveis no inspetor de cada modelo.

O OBJ contém a geometria na pose atual, sem materiais, rig ou clipes. O GLB original mantém os dados do autor; o seu download foi conferido por SHA-256. A edição de cor e escala no estúdio não altera esse arquivo original. O HTML de jogo incorpora o personagem/objeto selecionado e o companheiro quando aplicável; os controles movimentam o grupo e usam apenas clipes disponíveis.

## Fontes e licença

- Quaternius: modelos publicados no perfil do autor em `https://poly.pizza/u/Quaternius`, com links e declarações CC0 por modelo.
- Kenney: Nature Kit oficial, `https://kenney.nl/assets/nature-kit`, com a licença original incluída.

`assets/catalog.json` registra o catálogo efetivamente exibido, autor, página do modelo, download, licença, nome original, tamanho e SHA-256. `assets/licenses/` guarda a licença Kenney e evidências das páginas de cada modelo. Consulte também `assets/SOURCES.md`.

Os links Google Drive de alguns pacotes Quaternius retornaram “Quota exceeded”. Nesses casos foram usados os GLBs publicados pelo próprio autor no Poly Pizza, sem contornar a restrição do Drive. Nenhum arquivo premium ou com licença de redistribuição desconhecida foi incluído.

## Desenvolvimento

- `src/web-models.js`: importação, clonagem de skins, materiais, animações, catálogo e exportação.
- `assets/models/`: arquivos originais.
- `assets/catalog-parts/`: metadados de aquisição, incluindo as alternativas fora do catálogo.
- `scripts/build-web-studio.py`: verifica os hashes e incorpora o catálogo selecionado, GLBs comprimidos e miniaturas no HTML.
- `legacy/procedural-studio.html`: versão anterior preservada e base da interface reutilizada. A biblioteca visível e o construtor de modelos são substituídos pelo módulo GLB no build atual.

Para atualizar o HTML:

```sh
python scripts/build-web-studio.py
```

Para validar, com um servidor iniciado:

```sh
BASE_URL=http://127.0.0.1:8000 node scripts/validate-web-studio.cjs
```

A validação atual abre todos os modelos em Chromium, confere o uso das geometrias originais, materiais, clipes e dimensões, testa filtros, restauração de materiais, companheiro, cena, exportações, SHA do GLB e movimento/pulo no HTML exportado. As requisições externas ficam bloqueadas. Os scripts `validate-expansion.cjs` e `validate-family-catalog.cjs` pertencem às versões procedurais anteriores; não descrevem a biblioteca atual.

Dependências incorporadas: Three.js r128, OrbitControls, GLTFLoader e SkeletonUtils (MIT), Tailwind CSS (MIT), Font Awesome Free 6.4 (ícones CC BY 4.0, fontes SIL OFL 1.1, código MIT). Avisos de licença das distribuições foram mantidos.
