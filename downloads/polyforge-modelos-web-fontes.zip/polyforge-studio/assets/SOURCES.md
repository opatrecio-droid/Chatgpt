# Fontes dos modelos exibidos

Todos os arquivos abaixo foram publicados com licença CC0 1.0. O GLB original é mantido e conferido por SHA-256 no build. A evidência de cada licença está em `assets/licenses/`.

| Modelo exibido | Autor | Página do modelo | Licença |
| --- | --- | --- | --- |
| Aventureiro | Quaternius | [Adventurer](https://poly.pizza/m/ZwF0K7WBmu) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Capitão pirata | Quaternius | [Pirate Captain](https://poly.pizza/m/sN18LyyHAU) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Ninja | Quaternius | [Ninja](https://poly.pizza/m/xGYmeDpfTu) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Arbusto florido | Quaternius | [Bush with Flowers](https://poly.pizza/m/U1ymDy8tbY) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Cogumelo | Quaternius | [Mushroom](https://poly.pizza/m/aOW08oSrd4) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Cristal | Quaternius | [Big Crystal](https://poly.pizza/m/pf5lzmgr2J) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Flores | Quaternius | [Flower Group](https://poly.pizza/m/hfPzQAedOe) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Grama | Quaternius | [Grass](https://poly.pizza/m/vUJjrRsFp4) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Palmeira | Quaternius | [Palm Tree](https://poly.pizza/m/DsrrAYmucG) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Pinheiro | Quaternius | [Pine](https://poly.pizza/m/Zt62gceKXZ) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Planta de folhas largas | Quaternius | [Plant Big](https://poly.pizza/m/MbhbP7JrTI) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Rochas | Quaternius | [Rocks](https://poly.pizza/m/fy3szRMvuE) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Samambaia | Quaternius | [Fern](https://poly.pizza/m/jqcanvH7D6) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Árvore retorcida | Quaternius | [Twisted Tree](https://poly.pizza/m/8oraKn9m0x) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Árvore seca | Quaternius | [Dead Tree](https://poly.pizza/m/CD4edbPSGm) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Alpaca | Quaternius | [Alpaca](https://poly.pizza/m/bCVFD48i2l) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Burro | Quaternius | [Donkey](https://poly.pizza/m/qmX6nhnvp7) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Cavalo | Quaternius | [Horse](https://poly.pizza/m/qvTrSG9pZF) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Cervo | Quaternius | [Deer](https://poly.pizza/m/T6Cs7tmMHJ) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Husky | Quaternius | [Husky](https://poly.pizza/m/wcWiuEqwzq) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Lobo | Quaternius | [Wolf](https://poly.pizza/m/P1gU3Qkr9r) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Raposa | Quaternius | [Fox](https://poly.pizza/m/Bc97C66HKi) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Touro | Quaternius | [Bull](https://poly.pizza/m/a8PIIYwF7r) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Vaca | Quaternius | [Cow](https://poly.pizza/m/26zM1outCr) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Veado com galhadas | Quaternius | [Stag](https://poly.pizza/m/tQdzbZ1Cmw) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Barraca | Kenney | [Tent Detailed Closed](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Cama | Kenney | [Bed](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Fogueira | Kenney | [Campfire Logs](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Obelisco | Kenney | [Statue Obelisk](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Placa | Kenney | [Sign](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Ponte de madeira | Kenney | [Bridge Wood](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Portão de cerca | Kenney | [Fence Gate](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Remo | Kenney | [Canoe Paddle](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Vaso | Kenney | [Pot Large](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Canoa | Kenney | [Canoe](https://kenney.nl/assets/nature-kit) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
